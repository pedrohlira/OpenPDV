 /*  BEMATECH S.A

   Descricao  : Aplicativo exemplo para teste cat 52
		Linguagem C, usando o compilador gcc do Linux

*****************************************************************************/
#include <stdio.h>
#include <string.h>

//---------------------------------------------------------------------------//
//                          Prototipo das funcoes                            //
//---------------------------------------------------------------------------//
void CuponsMFD(void);
void ItensMFD(void);
void itens(void);
void Cupons(void);
void naoFiscalIntens(void);
void naoFiscalCupons(void);
void naoFiscalIntensMFD(void);
void naoFiscalCuponsMFD(void);
void GeraArquivoComando( char * Comando );


int main (void)
{
    int  RetFunction = 0;
    int  Opcao = 0;
    char Aux;

    do
    {
	system("clear");

	printf("                    Programa para Teste - Cat 52\n");

	printf("\n [ 1 ] - Cupons                                     " );
	printf("\n [ 2 ] - Cupons MFD                                 " );
	printf("\n [ 3 ] - Recebimento não fiscal                     " );
	printf("\n [ 4 ] - Recebimento não fiscal MFD                 " );
	printf("\n [ 0 ] - Sair" );

	printf("\n\n Digite a Opcao: " );

	scanf( "%d", &Opcao);
	switch( Opcao )
	{
	    case 1:
		Cupons();
		sleep(30);
            	break;

	    case 2:
		CuponsMFD();
		break;

	    case 3:
		naoFiscalCupons();
            	break;

	    case 4:
		naoFiscalCuponsMFD();
            	break;
	}

    }while( Opcao != 0 );
    system("clear");

return 0;

} //Fim do Main

void CuponsMFD(void)
{

	//Abre cupom 1
	GeraArquivoComando("\x1b|00|\x1b");

	//Itens 1
	ItensMFD();

	//Inicia Fechamento cupom 1
	GeraArquivoComando("\x1b|32|D|0000|\x1b");
	//Subtotaliza 1
	GeraArquivoComando("\x1b|103|\x1b");
	//Termina 1
	GeraArquivoComando("\x1b|34|\x1b");

	usleep(500000);

	//Abre cupom 2
	GeraArquivoComando("\x1b|00|123456789|Maria|x|\x1b");

	//Itens 2
	ItensMFD();

	//Inicia Fechamento cupom 2
	//GeraArquivoComando("\x1b|32|\x1b");
	//Subtotaliza 2
	GeraArquivoComando("\x1b|103|\x1b");
	//Acrescimo cupom 2
	GeraArquivoComando("\x1b|104|A|1000|\x1b"); // acrescimo de 10%
	//totaliza cupom 2
	GeraArquivoComando("\x1b|106|\x1b");
	//Forma de pagamento 2
	GeraArquivoComando("\x1b|72|02|00000000001000|\x1b");
	//Termina 2
	GeraArquivoComando("\x1b|34|\x1b");

	usleep(500000);

	//Abre cupom 3
	GeraArquivoComando("\x1b|00|01234567890|Joao|x|\x1b");

	//Itens 3
	ItensMFD();

	//Inicia Fechamento cupom 3
	//GeraArquivoComando("\x1b|32|\x1b");
	//Subtotaliza 3
	GeraArquivoComando("\x1b|103|\x1b");
	//Desconto cupom 3
	GeraArquivoComando("\x1b|104|D|1000|\x1b"); // desconto de 10%
	//totaliza cupom 3
	GeraArquivoComando("\x1b|106|\x1b");
	//Forma de pagamento 3
	GeraArquivoComando("\x1b|72|02|00000000001000|\x1b");
	//Termina 3
	GeraArquivoComando("\x1b|34|\x1b");

	usleep(500000);

	//Abre cupom 4
	GeraArquivoComando("\x1b|00|123456789|Maria|w|\x1b");

	//Itens 4
	ItensMFD();

	//Inicia Fechamento cupom 4
	//GeraArquivoComando("\x1b|32|\x1b");
	//Subtotaliza 4
	GeraArquivoComando("\x1b|103|\x1b");
	//Desconto cupom 4
	GeraArquivoComando("\x1b|104|D|1000|\x1b"); // desconto de 10%
	//Acrescimo cupom 4
	GeraArquivoComando("\x1b|104|a|00001000|\x1b"); // acrescimo valor
	//totaliza cupom 4
	GeraArquivoComando("\x1b|106|\x1b");
	//Forma de pagamento 4
	GeraArquivoComando("\x1b|72|02|00000000001000|\x1b");
	//Termina 4
	GeraArquivoComando("\x1b|34|\x1b");

	usleep(500000);

	//Abre cupom 5
	GeraArquivoComando("\x1b|00|01234567890|Joao|w|\x1b");

	//Itens 5
	ItensMFD();

	//Inicia Fechamento cupom 5
	//GeraArquivoComando("\x1b|32|\x1b");
	//Subtotaliza 5
	GeraArquivoComando("\x1b|103|\x1b");
	//Acrescimo cupom 5
	GeraArquivoComando("\x1b|104|A|1000|\x1b"); // acrescimo %
	//Desconto cupom 5
	GeraArquivoComando("\x1b|104|d|00001000|\x1b"); // desconto valor
	//Cancela desconto 5
	GeraArquivoComando("\x1b|105|D|\x1b");
	//totaliza cupom 5
	GeraArquivoComando("\x1b|106|\x1b");
	//Forma de pagamento 5
	GeraArquivoComando("\x1b|72|02|00000000001000|\x1b");
	//Termina 5
	GeraArquivoComando("\x1b|34|\x1b");

	usleep(500000);


	//Abre cupom 6
	GeraArquivoComando("\x1b|00|123456789|Maria|r|\x1b");

	//Itens 6
	ItensMFD();

	//Inicia Fechamento cupom 6
	//GeraArquivoComando("\x1b|32|\x1b");
	//Subtotaliza 6
	GeraArquivoComando("\x1b|103|\x1b");
	//Acrescimo cupom 6
	GeraArquivoComando("\x1b|104|A|1000|\x1b"); // acrescimo %
	//Desconto cupom 6
	GeraArquivoComando("\x1b|104|D|1000|\x1b"); // desconto %
	//Cancela desconto 6
	GeraArquivoComando("\x1b|105|D|\x1b");
	//totaliza cupom 6
	GeraArquivoComando("\x1b|106|\x1b");
	//Forma de pagamento 6
	GeraArquivoComando("\x1b|72|02|00000000001000|\x1b");
	//Termina 6
	GeraArquivoComando("\x1b|34|\x1b");

	usleep(500000);

	//Abre cupom 7
	GeraArquivoComando("\x1b|00|01234567890|Joao|o|\x1b");

	//Itens 7
	ItensMFD();

	//Inicia Fechamento cupom 7
	//GeraArquivoComando("\x1b|32|\x1b");
	//Subtotaliza 7
	GeraArquivoComando("\x1b|103|\x1b");
	//Acrescimo cupom 7
	GeraArquivoComando("\x1b|104|A|1000|\x1b"); // acrescimo %
	//Desconto cupom 7
	GeraArquivoComando("\x1b|104|D|1000|\x1b"); // desconto %
	//Cancela desconto 7
	GeraArquivoComando("\x1b|105|A|\x1b");
	//totaliza cupom 7
	GeraArquivoComando("\x1b|106|\x1b");
	//Forma de pagamento 7
	GeraArquivoComando("\x1b|72|02|00000000001000|\x1b");
	//Termina 7
	GeraArquivoComando("\x1b|34|\x1b");

	usleep(500000);

	//Abre cupom 8
	GeraArquivoComando("\x1b|00|123456789|Maria|x|\x1b");

	//Itens 8
	ItensMFD();

	//Inicia Fechamento cupom 8
	//GeraArquivoComando("\x1b|32|\x1b");
	//Subtotaliza 8
	GeraArquivoComando("\x1b|103|\x1b");
	//Desconto cupom 8
	GeraArquivoComando("\x1b|104|D|1000|\x1b"); // desconto %
	//Acrescimo cupom 8
	GeraArquivoComando("\x1b|104|A|1000|\x1b"); // acrescimo %
	//Cancela cupom 8
	GeraArquivoComando("\x1b|14|\x1b");


}

void ItensMFD(void)
{
	char strComando[200];

	memset(strComando, '\x0',  200);
	//printf("iniciando o teste:");

	//Vende Item 1
        sprintf( strComando, "\x1b|09|01|abacate|FF|01|1000|000|\x1b");
	GeraArquivoComando( strComando );

	//Item 2
        sprintf( strComando, "\x1b|09|02|banana|FF|02|1000|000|\x1b" );
	GeraArquivoComando( strComando );
	//Desconto item 2
	GeraArquivoComando("\x1b|93|D|002|1000|\x1b"); // desconto de 10%

	//Item 3
        sprintf( strComando, "\x1b|09|03|caju|FF|03|1000|000|\x1b" );
	GeraArquivoComando( strComando );
	//Acrescimo item 3
	GeraArquivoComando("\x1b|93|A|003|1000|\x1b"); // acrescimo de 10%

	//Item 4
        sprintf( strComando, "\x1b|09|04|damasco|FF|04|1000|000|\x1b" );
	GeraArquivoComando( strComando );
	//Acrescimo item 4
	GeraArquivoComando("\x1b|93|A|004|1000|\x1b"); // acrescimo de 10%
	//Desonto item 4
	GeraArquivoComando("\x1b|93|D|004|1000|\x1b"); // desconto de 10%

	//Item 5
        sprintf( strComando, "\x1b|09|05|embauba|FF|05|1000|000|\x1b" );
	GeraArquivoComando( strComando );
	//Desonto item 5 valor
	GeraArquivoComando("\x1b|93|D|005|00001000|\x1b"); // desconto valor

	//Item 6
        sprintf( strComando, "\x1b|09|06|framboesa|FF|06|1000|000|\x1b" );
	GeraArquivoComando( strComando );
	//Desonto item 5 valor
	GeraArquivoComando("\x1b|93|A|006|00001000|\x1b"); // acrescimo valor


	//Item 7
        sprintf( strComando, "\x1b|09|07|goiaba|FF|07|1000|000|\x1b" );
	GeraArquivoComando( strComando );
	//Desonto item 7
	GeraArquivoComando("\x1b|93|D|007|00001000|\x1b"); // desconto valor
	//Acrescimo item 7
	GeraArquivoComando("\x1b|93|A|007|00001000|\x1b"); // acrescimo valor


	//Item 8
        sprintf( strComando, "\x1b|09|08|hackberry|FF|08|1000|000|\x1b" );
	GeraArquivoComando( strComando );
	//Acrescimo item 8
	GeraArquivoComando("\x1b|93|A|008|00001000|\x1b"); // acrescimo valor
	//Desonto item 8
	GeraArquivoComando("\x1b|93|D|008|00001000|\x1b"); // desconto valor


	//Item 9
        sprintf( strComando, "\x1b|09|09|inga|FF|09|1000|000|\x1b" );
	GeraArquivoComando( strComando );
	//Desonto item 9
	GeraArquivoComando("\x1b|93|D|009|1000|\x1b"); // desconto %
	//Acrescimo item 9
	GeraArquivoComando("\x1b|93|A|009|1000|\x1b"); // acrescimo %


	//Item 10
        sprintf( strComando, "\x1b|09|10|jaca|FF|10|1000|000|\x1b" );
	GeraArquivoComando( strComando );
	//Desonto item 10
	GeraArquivoComando("\x1b|93|D|010|1000|\x1b"); // desconto %
	//Cancela desonto item 10
	GeraArquivoComando("\x1b|114|D|010|\x1b");


	//Item 11
        sprintf( strComando, "\x1b|09|11|kiwi|FF|11|1000|000|\x1b" );
	GeraArquivoComando( strComando );
	//Desonto item 11
	GeraArquivoComando("\x1b|93|D|011|00001000|\x1b"); // desconto valor
	//Cancela desonto item 11
	GeraArquivoComando("\x1b|114|D|011|\x1b");

	//Item 12
        sprintf( strComando, "\x1b|09|12|limao|FF|12|1000|000|\x1b" );
	GeraArquivoComando( strComando );
	//Acrescimo item 12
	GeraArquivoComando("\x1b|93|A|012|00001000|\x1b"); // acrescimo valor
	//Desonto item 12
	GeraArquivoComando("\x1b|93|D|012|1000|\x1b"); // desconto %
	//Cancela acrescimo item 12
	GeraArquivoComando("\x1b|114|A|012|\x1b");
	//Cancela desconto item 12
	GeraArquivoComando("\x1b|114|D|012|\x1b");

	//Item 13
        sprintf( strComando, "\x1b|09|13|maca|FF|13|1000|000|\x1b" );
	GeraArquivoComando( strComando );
	//Desonto item 13
	GeraArquivoComando("\x1b|93|D|013|1000|\x1b"); // desconto %
	//Acrescimo item 13
	GeraArquivoComando("\x1b|93|A|013|1000|\x1b"); // acrescimo %
	//Cancela item 13
	GeraArquivoComando("\x1b|13|\x1b");

}

void itens(void)
{
	char strComando[200];

	//Vende Item 1
        sprintf( strComando, "\x1b|09|01|Abacate|FF|1|1000|000|\x1b" );
	GeraArquivoComando( strComando );

	//Vende Item 2
        sprintf( strComando, "\x1b|09|02|Banana|FF|2|1000|1000|\x1b" );
	GeraArquivoComando( strComando );

	//Vende Item 3
        sprintf( strComando, "\x1b|09|03|Caju|FF|3|1000|00001000|\x1b" );
	GeraArquivoComando( strComando );

	//Vende Item 4
        sprintf( strComando, "\x1b|09|01|Damasco|FF|3|1000|000|\x1b" );
	GeraArquivoComando( strComando );
	//Cancela item 4
	GeraArquivoComando("\x1b|13|\x1b");


}

void Cupons(void)
{
	//Abre cupom 1
	GeraArquivoComando("\x1b|00|01234567890|Joao Ninguem|Rua Sem Nome, s/n|\x1b");

	itens();

	//Inicia Fechamento cupom 1
	GeraArquivoComando("\x1b|32|D|0000|\x1b");
	//Subtotaliza 1
	GeraArquivoComando("\x1b|103|\x1b");
	//Termina 1
	GeraArquivoComando("\x1b|34|\x1b");


	usleep(500000);
	//Abre cupom 2
	GeraArquivoComando("\x1b|00|01234567890|Maria Ninguem|Rua Sem Nome, s/n|\x1b");

	itens();

	//Subtotaliza 2
	GeraArquivoComando("\x1b|103|\x1b");
	//Desconto 2
	GeraArquivoComando("\x1b|104|D|1000|\x1b"); // desconto de 10%
	//totaliza cupom 2
	GeraArquivoComando("\x1b|106|\x1b");
	//Forma de pagamento 2
	GeraArquivoComando("\x1b|72|02|00000000001000|\x1b");
	//Termina 2
	GeraArquivoComando("\x1b|34|\x1b");


	usleep(500000);
	//Abre cupom 3
	GeraArquivoComando("\x1b|00|01234567890|Joao Ninguem|Rua Sem Nome, s/n|\x1b");

	itens();

	//Subtotaliza 3
	GeraArquivoComando("\x1b|103|\x1b");
	//Acrescimo 3
	GeraArquivoComando("\x1b|104|a|00001000|\x1b"); // acrescimo de valor
	//totaliza cupom 3
	GeraArquivoComando("\x1b|106|\x1b");
	//Forma de pagamento 3
	GeraArquivoComando("\x1b|72|02|00000000001000|\x1b");
	//Termina 3
	GeraArquivoComando("\x1b|34|\x1b");


	usleep(500000);
	//Abre cupom 4
	GeraArquivoComando("\x1b|00|01234567890|Maria Ninguem|Rua Sem Nome, s/n|\x1b");

	itens();

	//Subtotaliza 4
	GeraArquivoComando("\x1b|103|\x1b");
	//Acrescimo 4
	GeraArquivoComando("\x1b|104|A|1000|\x1b"); // acrescimo de valor
	//totaliza cupom 4
	GeraArquivoComando("\x1b|106|\x1b");
	//Forma de pagamento 4
	GeraArquivoComando("\x1b|72|02|00000000001000|\x1b");
	//Cancela cupom 4
	GeraArquivoComando("\x1b|14|\x1b");


}

void naoFiscalIntens(void)
{

	//Recebimento 1
	GeraArquivoComando("\x1b|25|01|00000000020000|Dinheiro|\x1b");

	//Recebimento 2
	GeraArquivoComando("\x1b|25|02|00000000010000|Cartao|\x1b");

	//Recebimento 3
	GeraArquivoComando("\x1b|25|03|00000000015000|Dinheiro|\x1b");
}

void naoFiscalCupons(void)
{
	//Nomeia totalizador
	GeraArquivoComando("\x1b|40|01|Conta de Luz|\x1b");
	GeraArquivoComando("\x1b|40|02|Conta de Agua|\x1b");
	GeraArquivoComando("\x1b|40|03|Conta de Telefone|\x1b");

	naoFiscalIntens();

	naoFiscalIntens();
	//Cancela item generico
	GeraArquivoComando("\x1b|31|0002|\x1b");

	//Relatorio gerencial
	GeraArquivoComando("\x1b|20|Management Report - Bematech Management Report - Bematech Management Report - Bematech Management Report - Bematech |\x1b");
	//Fecha relatorio gerencial
	GeraArquivoComando("\x1b|21|\x1b");


	//sleep(10);
}


void naoFiscalIntensMFD(void)
{

	//Recebimento 1
	GeraArquivoComando("\x1b|78|01|00000000010000|\x1b");

	//Recebimento 2
	GeraArquivoComando("\x1b|78|02|00000000005000|\x1b");
	//Desconto no recebimento nao fiscal
	GeraArquivoComando("\x1b|117|D|002|1000|\x1b");

	//Recebimento 3
	GeraArquivoComando("\x1b|78|03|00000000015000|\x1b");
	//Acrescimo no recebimento nao fiscal
	GeraArquivoComando("\x1b|117|A|003|1000|\x1b");

	//Recebimento 4
	GeraArquivoComando("\x1b|78|01|00000000010000|\x1b");
	//Acrescimo no recebimento nao fiscal
	GeraArquivoComando("\x1b|117|A|004|1000|\x1b");
	//Desconto no recebimento nao fiscal
	GeraArquivoComando("\x1b|117|D|004|1000|\x1b");

	//Recebimento 5
	GeraArquivoComando("\x1b|78|02|00000000005000|\x1b");
	//Desconto no recebimento nao fiscal
	GeraArquivoComando("\x1b|117|D|005|00001000|\x1b");


	//Recebimento 6
	GeraArquivoComando("\x1b|78|03|00000000015000|\x1b");
	//Acrescimo no recebimento nao fiscal
	GeraArquivoComando("\x1b|117|A|006|00001000|\x1b");


	//Recebimento 7
	GeraArquivoComando("\x1b|78|01|00000000010000|\x1b");
	//Desconto no recebimento nao fiscal
	GeraArquivoComando("\x1b|117|D|007|00001000|\x1b");
	//Acrescimo no recebimento nao fiscal
	GeraArquivoComando("\x1b|117|A|007|00001000|\x1b");

	//Recebimento 8
	GeraArquivoComando("\x1b|78|02|00000000005000|\x1b");
	//Acrescimo no recebimento nao fiscal
	GeraArquivoComando("\x1b|117|A|008|1000|\x1b");
	//Desconto no recebimento nao fiscal
	GeraArquivoComando("\x1b|117|D|008|00001000|\x1b");

	//Recebimento 9
	GeraArquivoComando("\x1b|78|03|00000000015000|\x1b");
	//Desconto no recebimento nao fiscal
	GeraArquivoComando("\x1b|117|D|009|1000|\x1b");
	//Acrescimo no recebimento nao fiscal
	GeraArquivoComando("\x1b|117|A|009|00001000|\x1b");

	//Recebimento 10
	GeraArquivoComando("\x1b|78|01|00000000010000|\x1b");
	//Acrescimo no recebimento nao fiscal
	GeraArquivoComando("\x1b|117|A|010|1000|\x1b");
	// Cancelamento do acrescimo
	GeraArquivoComando("\x1b|118|A|010|\x1b");


	//Recebimento 11
	GeraArquivoComando("\x1b|78|02|00000000005000|\x1b");
	//Desconto no recebimento nao fiscal
	GeraArquivoComando("\x1b|117|D|011|00001000|\x1b");
	// Cancelamento do acrescimo
	GeraArquivoComando("\x1b|118|D|011|\x1b");


	//Recebimento 12
	GeraArquivoComando("\x1b|78|03|00000000005000|\x1b");
	//Acrescimo no recebimento nao fiscal
	GeraArquivoComando("\x1b|117|A|012|00001000|\x1b");
	//Desconto no recebimento nao fiscal
	GeraArquivoComando("\x1b|117|D|012|00001000|\x1b");
	// Cancelamento do acrescimo
	GeraArquivoComando("\x1b|118|A|012|\x1b");
	// Cancelamento do desconto
	GeraArquivoComando("\x1b|118|D|012|\x1b");

	//Recebimento 13
	GeraArquivoComando("\x1b|78|01|00000000010000|\x1b");
	//Acrescimo no recebimento nao fiscal
	GeraArquivoComando("\x1b|117|A|013|1000|\x1b");
	//Desconto no recebimento nao fiscal
	GeraArquivoComando("\x1b|117|D|013|1000|\x1b");
	// Cancela item
	GeraArquivoComando("\x1b|116|013|\x1b");



	//sleep(5);
}

void naoFiscalCuponsMFD(void)
{

	//Nomeia totalizador
	GeraArquivoComando("\x1b|40|01|Power bill|\x1b");
	GeraArquivoComando("\x1b|40|02|Water bill|\x1b");
	GeraArquivoComando("\x1b|40|03|Phone bill|\x1b");


	//Abre recebimento nao fiscal - 1
	GeraArquivoComando("\x1b|77|01234567890|Joao Ninguem|Rua Sem Nome, S/n|\x1b");

	naoFiscalIntensMFD();

	// Sobtotaliza recebimento nao fiscal
	GeraArquivoComando("\x1b|107|\x1b");
	// Totaliza recebimento nao fiscal
	GeraArquivoComando("\x1b|110|\x1b");
	// Fecha recebimento nao fiscal
	GeraArquivoComando("\x1b|34|Obrigado e volte sempre|\x1b");


	usleep(500000);


	//Abre recebimento nao fiscal - 2
	GeraArquivoComando("\x1b|77|123456789|Maria Ninguem|Rua Sem Nome, S/n|\x1b");

	naoFiscalIntensMFD();

	// Sobtotaliza recebimento nao fiscal
	GeraArquivoComando("\x1b|107|\x1b");
	// Acrescimo em subtotal de recebimento
	GeraArquivoComando("\x1b|108|A|1000|\x1b");
	// Totaliza recebimento nao fiscal
	GeraArquivoComando("\x1b|110|\x1b");
	// Fecha recebimento nao fiscal
	GeraArquivoComando("\x1b|34|Obrigado e volte sempre|\x1b");


	usleep(500000);


	//Abre recebimento nao fiscal - 3
	GeraArquivoComando("\x1b|77|01234567890|Joao Ninguem|Rua Sem Nome, S/n|\x1b");

	naoFiscalIntensMFD();

	// Sobtotaliza recebimento nao fiscal
	GeraArquivoComando("\x1b|107|\x1b");
	// Desconto em subtotal de recebimento
	GeraArquivoComando("\x1b|108|D|1000|\x1b");
	// Totaliza recebimento nao fiscal
	GeraArquivoComando("\x1b|110|\x1b");
	// Fecha recebimento nao fiscal
	GeraArquivoComando("\x1b|34|Obrigado e volte sempre|\x1b");


	usleep(500000);


	//Abre recebimento nao fiscal - 4
	GeraArquivoComando("\x1b|77|12345678909|Maria Ninguem|Rua Sem Nome, S/n|\x1b");

	naoFiscalIntensMFD();

	// Sobtotaliza recebimento nao fiscal
	GeraArquivoComando("\x1b|107|\x1b");
	// Desconto em subtotal de recebimento
	GeraArquivoComando("\x1b|108|D|1000|\x1b");
	// Acrescimo em subtotal de recebimento $
	GeraArquivoComando("\x1b|108|a|1000|\x1b");
	// Totaliza recebimento nao fiscal
	GeraArquivoComando("\x1b|110|\x1b");
	// Fecha recebimento nao fiscal
	GeraArquivoComando("\x1b|34|Obrigado e volte sempre|\x1b");


	usleep(500000);


	//Abre recebimento nao fiscal - 5
	GeraArquivoComando("\x1b|77|0123456789090|Joao Ninguem|Rua Sem Nome, S/n|\x1b");

	naoFiscalIntensMFD();

	// Sobtotaliza recebimento nao fiscal
	GeraArquivoComando("\x1b|107|\x1b");
	// Acrescimo em subtotal de recebimento
	GeraArquivoComando("\x1b|108|A|1000|\x1b");
	// Desconto em subtotal de recebimento
	GeraArquivoComando("\x1b|108|d|1000|\x1b");
	// Cancela acrescimo ou desconto em subtotal de recebimento
	GeraArquivoComando("\x1b|109|D|\x1b");
	// Totaliza recebimento nao fiscal
	GeraArquivoComando("\x1b|110|\x1b");
	// Fecha recebimento nao fiscal
	GeraArquivoComando("\x1b|34|Obrigado e volte sempre|\x1b");


	usleep(500000);


	//Abre recebimento nao fiscal - 6
	GeraArquivoComando("\x1b|77|12345678909|Maria Ninguem|Rua Sem Nome, S/n|\x1b");

	naoFiscalIntensMFD();

	// Sobtotaliza recebimento nao fiscal
	GeraArquivoComando("\x1b|107|\x1b");
	// Acrescimo em subtotal de recebimento
	GeraArquivoComando("\x1b|108|A|1000|\x1b");
	// Desconto em subtotal de recebimento
	GeraArquivoComando("\x1b|108|D|1000|\x1b");
	// Cancela acrescimo ou desconto em subtotal de recebimento
	GeraArquivoComando("\x1b|109|A|\x1b");
	// Totaliza recebimento nao fiscal
	GeraArquivoComando("\x1b|110|\x1b");
	// Fecha recebimento nao fiscal
	GeraArquivoComando("\x1b|34|Obrigado e volte sempre|\x1b");


	usleep(500000);


	//Abre recebimento nao fiscal - 7
	GeraArquivoComando("\x1b|77|012345678909|Joao Ninguem|Rua Sem Nome, S/n|\x1b");

	naoFiscalIntensMFD();

	// Sobtotaliza recebimento nao fiscal
	GeraArquivoComando("\x1b|107|\x1b");
	// Desconto em subtotal de recebimento $
	GeraArquivoComando("\x1b|108|d|1000|\x1b");
	// Acrescimo em subtotal de recebimento $
	GeraArquivoComando("\x1b|108|a|1000|\x1b");
	// Cancela acrescimo ou desconto em subtotal de recebimento
	GeraArquivoComando("\x1b|109|D|\x1b");
	// Totaliza recebimento nao fiscal
	GeraArquivoComando("\x1b|110|\x1b");
	// Fecha recebimento nao fiscal
	GeraArquivoComando("\x1b|34|Obrigado e volte sempre|\x1b");

	usleep(500000);


	//Abre recebimento nao fiscal - 8
	GeraArquivoComando("\x1b|77|0123456789090|Maria Ninguem|Rua Sem Nome, S/n|\x1b");

	naoFiscalIntensMFD();

	// Sobtotaliza recebimento nao fiscal
	GeraArquivoComando("\x1b|107|\x1b");
	// Desconto em subtotal de recebimento
	GeraArquivoComando("\x1b|108|D|1000|\x1b");
	// Acrescimo em subtotal de recebimento
	GeraArquivoComando("\x1b|108|A|1000|\x1b");
	// Cancela recebimento nao fiscal
	GeraArquivoComando("\x1b|81|0123456789090|Maria Ninguem|Rua Sem Nome, S/n|\x1b");


	//Relatorio gerencial
	GeraArquivoComando("\x1b|20|Management Report - Bematech Management Report - Bematech Management Report - Bematech Management Report - Bematech |\x1b");
	//Fecha relatorio gerencial
	GeraArquivoComando("\x1b|21|\x1b");


	//sleep(10);
}



void GeraArquivoComando( Comando )
char* Comando;
{
    FILE*   Handle;

    /* //DEBUG
    int i = 0;
    for (i = 0; i < strlen(Comando); i++)
    {
    	printf("\nComando[%d]: [%c], [%x]", i, Comando[i], Comando[i] );
    }
    getchar();
    */

    // abre o arquivo bemafilx.cmd
    if ((Handle = fopen("bemafilx.cmd", "wb")) == NULL)
    {
       printf("Erro ao criar o arquivo bemafilx.cmd.\n");
       return;
    }

    // grava o comando no arquivo
    fprintf( Handle, "%s", Comando );

    // fecha o arquivo status.txt
    fclose( Handle );


    // executa o programa bemafilx para enviar o comando para a impressora
    system( "./bemafilx.out" );
    return;
}


