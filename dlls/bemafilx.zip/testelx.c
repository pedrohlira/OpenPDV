 /*  BEMATECH - Ind. e Com. de Equip. Eletronicos S.A

   Descricao  : Aplicativo exemplo de comunicacao com as impressoras
                fiscais em linux utilizando o driver bemafilx.
                Linguagem C, usando o compilador gcc do Linux

*****************************************************************************/
#include <stdio.h>
#include <string.h>

//---------------------------------------------------------------------------//
//                          Defines                                          //
//---------------------------------------------------------------------------//
#define LF             "\x0A"
#define NEGRITO_ON      "\x1b\x45"
#define NEGRITO_OFF     "\x1b\x46"
#define EXPANDIDO_ON    "\x1b\x57\x31"
#define EXPANDIDO_OFF   "\x1b\x57\x30"
#define CONDENSADO_ON   "\x1b\x0f"
#define CONDENSADO_OFF  "\x12"
#define SUBLINHADO_ON   "\x1b\x2d\x31"
#define SUBLINHADO_OFF  "\x1b\x2d\x30"

// Comandos para impressao de codigo de barras
#define CMD_COD_EAN8	"\x1d\x6b\x03"  	// GS k 3 - codigo barras EAN-8
#define CMD_COD_EAN13	"\x1d\x6b\x02"  	// GS k 2 - codigo barras EAN-13
#define CMD_COD_CODE39	"\x1d\x6b\x04"  	// GS k 4 - codigo barras CODE-39
#define CMD_COD_CODABAR	"\x1d\x6b\x06"  	// GS k 5 - codigo barras CODABAR
#define CMD_COD_CODE93	"\x1d\x6b\x48"  	// GS k 72 - codigo barras CODE-93
#define CMD_COD_CODE128	"\x1d\x6b\x49"  	// GS k 73 - codigo barras CODE-128
#define CMD_COD_ITF		"\x1d\x6b\x05"  	// GS k 73 - codigo barras ITF
#define CMD_COD_ISBN	"\x1d\x6b\x15"  	// GS k 21 - codigo barras ISBN
#define CMD_COD_MSI		"\x1d\x6b\x16"  	// GS k 22 - codigo barras MSI
#define CMD_COD_PLESSEY	"\x1d\x6b\x17"  	// GS k 23 - codigo barras PLESSEY
#define CMD_COD_PDF417	"\x1d\x6b\x80"  	// GS k 128 - codigo barras PDF-417
#define CMD_COD_UPCA	"\x1d\x6b\x30"  	// GS k 0   - codigo barras UPC-A
#define CMD_COD_UPCE	"\x1d\x6b\x01"  	// GS k 1   - codigo barras UPC-E

// Codigos para impressao de codigo de barras
#define EAN13			"123456789012"
#define EAN8  			"1234567"
#define CODABAR			"123-456/001"
#define CODE39			"ABC-12345"
#define CODE93			"ABC-123__"
#define CODE128			"1234567890123"
#define ITF				"0123456789012345"
#define ISBN			"1-56592-292-X 90000"
#define MSI				"092581"
#define PLESSEY			"09adef"
#define PDF417			"Com a Bematech voce pode mais!"
#define UPCA			"12345678901"
#define UPCE			"123456"

// Margem do código de barras
#define MARGEM_DEFAULT			"\x1d\x6B\x84\x6e" 	// GS k 132 n onde 1 < n < 575

// Altura das barras do código de barras
#define ALTURA_DEFAULT			"\x1d\x68\xA2"  	// GS h n onde 1 < n < 255

// Largura das barras do código de barras
#define BARRAS_FINAS			"\x1d\x77\x02"  	// GS w 2
#define BARRAS_MEDIAS			"\x1d\x77\x03"  	// GS w 3
#define BARRAS_GROSSAS			"\x1d\x77\x04"  	// GS w 4

// Fonte utilizada para imprimir os caracteres do codigo de barras (HRI)
#define FONTE_NORMAL			"\x1d\x66\x30"  	// GS f 0
#define FONTE_CONDENSADA		"\x1d\x66\x31"  	// GS f 1

// Posicao dos caracteres do código de barras (HRI)
#define CARACTERES_NONE			"\x1d\x48\x30"  	// GS H 0
#define CARACTERES_ACIMA		"\x1d\x48\x31"  	// GS H 1
#define CARACTERES_ABAIXO		"\x1d\x48\x32"  	// GS H 2
#define CARACTERES_ABAIXO_ACIMA	"\x1d\x48\x33"  	// GS H 3

// Acionamento da guilhotina
#define CORTE_TOTAL				"\x1b\x69"  		// ESC 105
#define CORTE_PARCIAL			"\x1b\x6D"  		// ESC 109

#define BOOL           unsigned char
#define TRUE           1
#define FALSE          0


//---------------------------------------------------------------------------//
//                          Prototipo das funcoes                            //
//---------------------------------------------------------------------------//

void ComandosInicializacao   ( void );
void ComandosInicializacaoMFD( void );
void ComandosCupomFiscal     ( void );
void ComandosCupomFiscalMFD  ( void );
void RelatoriosFiscais       ( void );
void OperacoesNaoFiscais     ( void );
void InformacoesImpressora   ( void );
void GavetaAutenticacao      ( void );
void ImpressaoCheque         ( void );
void RetornoVariaveis        ( void );
void RetornoVariaveisMFD     ( void );
void RetornoVariaveis2MFD    ( void );
void GeraArquivoComando      ( char * );
void LeRetornoImpressora     ( int  );
void Recebimentos            ( void );
void ComprovanteCreditoDebito( void );
void CodigoBarras            ( void );
void EstornoCDCPosterior     ( void );
void EmitirCupomFiscal       ( void );
void EmitirCDC               ( void );
void TelaAtivaDesativa       ( char * );
int  LerRetorno              ( char * );

//---------------------------------------------------------------------------//
//                          Modulo principal                                 //
//---------------------------------------------------------------------------//

int main (void)
{
    int  RetFunction = 0;
    int  Opcao = 0;
    char Aux;

    do
    {
	system("clear");

	printf("                    Programa para Testes do Driver Linux Bemafilx\n");

	printf("\n [ 1 ] - Comandos de  Inicializacao                 " );
	printf("\n [ 2 ] - Comandos do  Cupom Fiscal                  " );
	printf("\n [ 3 ] - Comandos dos Relatorios Fiscais            " );
	printf("\n [ 4 ] - Comandos das Operacoes Nao Sujeitas ao ICMS" );
	printf("\n [ 5 ] - Comandos das Informacoes da Impressora     " );
	printf("\n [ 6 ] - Comandos da  Gaveta e de Autenticacao      " );
	printf("\n [ 7 ] - Comandos de  Impressao de Cheques          " );
	printf("\n [ 0 ] - Sair" );

	printf("\n\n Digite a Opcao: " );

	scanf( "%d", &Opcao);
	switch( Opcao )
	{
	    case 1:
		ComandosInicializacao();
            	break;

	    case 2:
            	ComandosCupomFiscal();
		break;

	    case 3:
		RelatoriosFiscais();
            	break;

	    case 4:
		OperacoesNaoFiscais();
            	break;

	    case 5:
		InformacoesImpressora();
            	break;

	    case 6:
		GavetaAutenticacao();
            	break;

	    case 7:
		ImpressaoCheque();
            	break;
	}

    }while( Opcao != 0 );
    system("clear");

return 0;

} //Fim do Main

//---------------------------------------------------------------------------//
//                        Implementacao das funcoes                          //
//---------------------------------------------------------------------------//

void ComandosInicializacao( void )
{
    int  Opcao = 0;
    int  Retorno[4];
    int  RetFunction = 0;
    char Var[3000];
    char Aux;

    do
    {

	memset(Var,  '\x0',3000);
	Retorno[0] = 0; Retorno[1] = 0; Retorno[2] = 0; Retorno[3] = 0;

	system("clear");

	printf("                       Comandos de Inicializacao\n");

	printf("\n [  1 ] - Altera Simbolo Moeda                   ");
	printf("\n [  2 ] - Adiciona Aliquota                      ");
	printf("\n [  3 ] - Programa Horario de Verao              ");
	printf("\n [  4 ] - Nomeia Totalizador Nao Sujeito ao ICMS ");
	printf("\n [  5 ] - Programa Arredondamento                ");
	printf("\n [  6 ] - Programa Truncamento                   ");
	printf("\n [  7 ] - Espaco Entre Linhas                    ");
	printf("\n [  8 ] - Linhas Entre Cupons                    ");
	printf("\n [  9 ] - Nomeia Departamento                    ");
	printf("\n [ 10 ] - Reseta Impressora                      ");
	printf("\n [ 11 ] - Outros Comandos MFD...                 ");
	printf("\n [  0 ] - Sair                                   ");

	printf("\n\n Digite a Opcao: " );

	scanf( "%d", &Opcao);
	switch( Opcao )
	{
	    case 1: // altera o simbolo da moeda - ESC 01
		GeraArquivoComando("\x1b|01| R|\x1b");
            	break;

	    case 2: // cadastra aliquota tributaria - ESC 07
		GeraArquivoComando("\x1b|07|1700|0|\x1b");
                break;

	    case 3: // programa/desprograma horario de verao - ESC 18
		GeraArquivoComando("\x1b|18|\x1b");
                break;

	    case 4: // nomeida totalizador nao sujeito ao ICMS - ESC 40
		GeraArquivoComando("\x1b|40|01|Conta de Telefone  |\x1b");
                break;

	    case 5: // programa arredondamento - ESC 39
		GeraArquivoComando("\x1b|39|1|\x1b");
                break;

	    case 6: // programa truncamento - ESC 39
		GeraArquivoComando("\x1b|39|0|\x1b");
                break;

	    case 7: // programa espaco entre as linhas no cupom - ESC 60
	            // (somente na MP40 FI II - o valor default da impressora
		    // e 0 e compreende entre a e 255)
		GeraArquivoComando("\x1b|60|000|\x1b");
                break;

	    case 8: // programa o numero de linhas entre os cupons - ESC 61
	            // (o valor default da imp. e 8 e compreende entre 0 e 255)
		GeraArquivoComando("\x1b|61|008|\x1b");
                break;

	    case 9: // nomeia departamento - ESC 65
		GeraArquivoComando("\x1b|65|02|Calcados  |\x1b");
                break;

	    case 10: // reseta a impressora caso esteja em erro - ESC 70
		GeraArquivoComando("\x1b|70|\x1b");
                break;

	    case 11: // outros comandos MFD
		ComandosInicializacaoMFD();
                break;

	} // fim do switch

	if ( Opcao > 0 && Opcao < 11 )
	{
	   // le o status e o retorno de informacoes dos arquivos status.txt e
	   // retorno.txt criados pelo bemafilx.out
	   LeRetornoImpressora(0);
	}
    }
    while( Opcao != 0 );
}

void ComandosInicializacaoMFD( void )
{
    int  Opcao = 0;
    int  Retorno[4];
    int  RetFunction = 0;
    char Var[3000];
    char Aux;

    do
    {
	memset(Var,  '\x0',3000);
	Retorno[0] = 0; Retorno[1] = 0; Retorno[2] = 0; Retorno[3] = 0;

	system("clear");

	printf("                       Comandos de Inicializacao\n");

	printf("\n [  1 ] - Ativa/desativa Corte Parcial Apos Cupom Fiscal             ");
	printf("\n [  2 ] - Ativa/desativa Sensor de Pouco Papel                       ");
	printf("\n [  3 ] - Ativa/desativa Tratamento ON-LINE OFF-LINE MFD             ");
	printf("\n [  4 ] - Ativa/desativa Cancelamento Automatico do Cupom as 2 hs    ");
	printf("\n [  5 ] - Ativa/desativa Corte do Proximo Documento                  ");
	printf("\n [  6 ] - Ativa/desativa Corte Total                                 ");
	printf("\n [  7 ] - Ativa/desativa Alinhamento da Descricao do Item a Esquerda ");
	printf("\n [  8 ] - Ativa/desativa Venda de Item em Uma Linha                  ");
	printf("\n [  9 ] - Ativa/desativa Guilhotina                                  ");
	printf("\n [ 10 ] - Programa Relatorio Gerencial                               ");
	printf("\n [ 11 ] - Ajusta Corte Parcial Guilhotina                            ");
	printf("\n [  0 ] - Sair                                                       ");

	printf("\n\n Digite a Opcao: " );

	scanf( "%d", &Opcao);
	switch( Opcao )
	{
	    case 1: // Ativa/desativa corte parcial apos cupom fiscal - ESC 121
        TelaAtivaDesativa("121");
        break;

        case 2: // Ativa/desativa sensor de pouco papel - ESC 62 61
            TelaAtivaDesativa("62|61");
            break;

	    case 3: // Ativa/desativa tratamento ON_LINE OFF-LINE - ESC 62 57
            TelaAtivaDesativa("62|57");
            break;

        case 4: // Ativa/desativa cancelamento automatico do cupom as 2 hs - ESC 62 70
            TelaAtivaDesativa("62|70");
            break;

	    case 5: // Ativa/desativa do proximo documento - ESC 62 58
            TelaAtivaDesativa("62|58");
            break;

	    case 6: // Ativa/desativa corte total - ESC 62 58
            TelaAtivaDesativa("62|63");
            break;

	    case 7: // Ativa/desativa alinhamento da descricao do item a esquerda - ESC 62 59
		    //GeraArquivoComando("\x1b|62|59|0|\x1b");
            TelaAtivaDesativa("62|59");
            break;

	    case 8: // Ativa/desativa venda de item em uma linha - ESC 62 60
		    //GeraArquivoComando("\x1b|62|60|viul2004|0|\x1b");
            TelaAtivaDesativa("62|60|viul2004");
            break;

	    case 9: // Ativa/desativa guilhotina - ESC 62 82
            TelaAtivaDesativa("62|82");
            break;

	    case 10: // programa relatorio gerencial - ESC 82
		GeraArquivoComando("\x1b|82|02|RELAT GERENCIAL 2|\x1b");
                break;

	    case 11: // ajusta corte parcial guilhotina - ESC 62 72
		GeraArquivoComando("\x1b|62|72|020|0|\x1b");
                break;

	} // fim do switch

	if ( Opcao > 0 && Opcao < 12 )
	{
	   // le o status e o retorno de informacoes dos arquivos status.txt e
	   // retorno.txt criados pelo bemafilx.out
	   LeRetornoImpressora(0);
	}
    }while( Opcao != 0 );
}

void ComandosCupomFiscal( void )
{
    int  Opcao = 0;
    int  Retorno[4];
    int  RetFunction = 0;
    char Var[3000];
    char Aux;                       /* variavel auxiliar                    */
    char Codigo[14];                /* codigo do produto 13 carac. + 1 null */
    char Descricao[30];             /* desc. do produto 29 carac.  + 1 null */
    char Aliquota[3];               /* indice aliquota 2 carac.    + 1 null */
    char Qtde[5];                   /* qtde inteira 4 carac.       + 1 null */
    char Valor[9];                  /* vlr unitario 8 carac.       + 1 null */
    char Desconto[5];               /* desc percentual 4 carac.    + 1 null */
    char strComando[200];           /* Comando enviado para a impressora    */

    do
    {
	memset(Var,        '\x0', 3000);
	memset(strComando, '\x0',  200);

	Retorno[0] = 0; Retorno[1] = 0; Retorno[2] = 0; Retorno[3] = 0;

	sprintf( Codigo,    "%s\x00", "0000000000001" );
	sprintf( Descricao, "%s\x00", "Impressora Fiscal Bematech   " );
	sprintf( Aliquota,  "%s\x00", "II" );
	sprintf( Qtde,      "%s\x00", "0001" );
	sprintf( Valor,     "%s\x00", "00000100" );
	sprintf( Desconto,  "%s\x00", "0000" );

	system("clear");

	printf("                       Comandos do Cupom Fiscal\n");

	printf("\n [  1 ] - Abre Cupom                                            " );
	printf("\n [  2 ] - Vende Item                                            " );
	printf("\n [  3 ] - Inicia Fechamento Cupom                               " );
	printf("\n [  4 ] - Verifica Forma de Pagamento	                          " );
	printf("\n [  5 ] - Efetua Forma Pagamento	                              " );
	printf("\n [  6 ] - Termina o Fechamento do Cupom                         " );
	printf("\n [  7 ] - Cancela Item Anterior                                 " );
	printf("\n [  8 ] - Cancela Item Generico                                 " );
	printf("\n [  9 ] - Cancela Cupom	 	                                  " );
	printf("\n [ 10 ] - Programa Unidade Medida                               " );
	printf("\n [ 11 ] - Aumenta Descricao do Item                             " );
    printf("\n [ 12 ] - Comandos do Cupom Fiscal MFD                          " );
	printf("\n [  0 ] - Sair                                                  " );

	printf("\n\n Digite a Opcao: " );

	scanf( "%d", &Opcao);
	switch( Opcao )
	{
	    case 1: // abre cupom - ESC 00
		    GeraArquivoComando("\x1b|00|\x1b");
            break;

	    case 2: // venda item - ESC 09
		    //GeraArquivoComando("\x1b|09|1234567890123|Teste De Produto.............|II|0001|00000100|0000|\x1b");
	        sprintf( strComando, "\x1b|09|%s|%s|%s|%s|%s|%s|\x1b", Codigo, Descricao,
		         Aliquota, Qtde, Valor, Desconto );
		    GeraArquivoComando( strComando );
        	break;

	    case 3: // inicia fechamento do cupom - ESC 32
		    GeraArquivoComando("\x1b|32|D|0000|\x1b");
            break;

	    case 4: // verifica forma de pagamento - ESC 71
		    GeraArquivoComando("\x1b|71|Cartao          |\x1b");
            break;

	    case 5: // efetua forma de pagamento - ESC 72
		    GeraArquivoComando("\x1b|72|02|00000000010000|\x1b");
            break;

	    case 6: // termina o fechamento do cupom fiscal - ESC 34
        //GeraArquivoComando("\x1b|34|\x1b");
		sprintf( strComando, "\x1b|34|");  // inicio do protocolo
		sprintf( strComando + strlen( strComando ), "\\%s%s\\%s%s",  NEGRITO_ON, "CLIENTE: ", NEGRITO_OFF, "Nome do cliente" );
		strcat( strComando, LF);
		sprintf( strComando + strlen( strComando ), "\\%s%s\\%s%s\n\n",  NEGRITO_ON, "COMENTARIO: ", NEGRITO_OFF, "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" );
		sprintf( strComando + strlen( strComando ), "\\%s%s\\%s",  EXPANDIDO_ON, "OBRIGADO E VOLTE SEMPRE", EXPANDIDO_OFF);
		strcat( strComando, "|\x1b");      // fim do protocolo
	    GeraArquivoComando( strComando );
        break;

	    case 7: // cancelamento do item anterior - ESC 13
            GeraArquivoComando("\x1b|13|\x1b");
            break;

	    case 8: // cancelamento de item generico - ESC 31
            GeraArquivoComando("\x1b|31|0001|\x1b");
            break;

	    case 9: // cancelamento do cupom - ESC 14
            GeraArquivoComando("\x1b|14|\x1b");
            break;

	    case 10: // programa unidade de medida - ESC 62 51
            GeraArquivoComando("\x1b|62|51|KG|\x1b");
            break;

	    case 11: // aumenta a descricao do item - ESC 62 52
            GeraArquivoComando("\x1b|62|52|Descricao do item com ate 200 caracteres|\x1b");
            break;

        case 12: // comandos do cupom fiscal MFD
            ComandosCupomFiscalMFD();
            break;

	} // fim do switch

	if ( Opcao != 0 && Opcao < 12 )
	{
	   // le o status e o retorno de informacoes dos arquivos status.txt e
	   // retorno.txt criados pelo bemafilx.out
	   if (Opcao == 4)
	   	  LeRetornoImpressora(1);
	   else
	   	  LeRetornoImpressora(0);
	}
    }
    while( Opcao != 0 );

}

void ComandosCupomFiscalMFD( void )
{
    int  Opcao = 0;
    char strComando[200];           /* Comando enviado para a impressora    */

    do
    {
    memset(strComando, '\x0',  200);

    system("clear");

    printf("                       Comandos do Cupom Fiscal MFD\n");

    printf("\n [  1 ] - Abre Cupom MFD                                        " );
    printf("\n [  2 ] - Vende Item com Descricao Extendida MFD                " );
    printf("\n [  3 ] - Vende Item com Arredondamento ou Truncamento MFD      " );
    printf("\n [  4 ] - Acrescimo ou Desconto Posterior no Item MFD           " );
    printf("\n [  5 ] - Cancela Acrescimo ou Desconto Posterior no Item MFD   " );
    printf("\n [  6 ] - Inicia Fechamento Cupom com Acrescimo e Desconto MFD  " );
    printf("\n [  7 ] - Subtotaliza o Cupom MFD                               " );
    printf("\n [  8 ] - Acrescimo ou Desconto no Subtotal do Cupom MFD        " );
    printf("\n [  9 ] - Cancela Acrescimo ou Desconto no Subtotal do Cupom MFD" );
    printf("\n [ 10 ] - Totaliza o Cupom MFD                                  " );
    printf("\n [ 11 ] - Efetua Forma Pagamento com Parcelamento MFD           " );
    printf("\n [ 12 ] - Termina o Fechamento do Cupom                         " );
    printf("\n [  0 ] - Sair                                                  " );

    printf("\n\n Digite a Opcao: " );

    scanf( "%d", &Opcao);
    //getchar(); // para retirar o ENTER do buffer
    switch( Opcao )
    {
        case 1: // abre o cupom fiscal MFD- ESC 00
            GeraArquivoComando("\x1b|00|1...5...10...15...20...25..29|Fulano de tal.5...20...25..29|Rua da Paz, 500   20...25...30...35...40...45...50...55...60...65...70...75...80|\x1b");
            break;

        case 2: // venda de item com descricao extendida - ESC 62 73
            GeraArquivoComando( "\x1b|62|73|12345678901234|II|UN|0001000|00005000|00000100|00000200|Venda  de item com descricao ate 200 caracteres 50...55...60...65...70...75...80...85...90...95..100..105..110..115..120..125..130..135..140..145..150..155..160..165..170..175..180..185..190..195..200|\x1b");
            break;

        case 3: // venda de item com arredondamento ou truncamento - ESC 62 87
            // truncamento
            GeraArquivoComando( "\x1b|62|87|12345678901234|II|UN|T|0001000|00001996|00000000|00000000|Venda de item com truncamento e descricao ate 200 caracteres...65...70...75...80...85...90...95..100..105..110..115..120..125..130..135..140..145..150..155..160..165..170..175..180..185..190..195..200|\x1b");

            // arredondamento
            GeraArquivoComando( "\x1b|62|87|12345678901234|II|UN|A|0001000|00001996|00000000|00000000|Venda de item com arredondamento e descricao ate 200 caracteres.....70...75...80...85...90...95..100..105..110..115..120..125..130..135..140..145..150..155..160..165..170..175..180..185..190..195..200|\x1b");            break;

        case 4: // acrescimo ou desconto posterior no item - ESC 93
            GeraArquivoComando("\x1b|93|D|001|1000|\x1b"); // desconto de 10%
            break;

        case 5: // cancela acrescimo ou desconto posterior no item - ESC 114
            GeraArquivoComando("\x1b|114|D|001|\x1b");
            break;

        case 6: // inicia o fechamento do cupom com acrescimo e desconto simultaneos - ESC 32
            GeraArquivoComando("\x1b|32|T|1000|1000|\x1b");
            break;

        case 7: // subtotaliza o cupom - ESC 103
            GeraArquivoComando("\x1b|103|\x1b");
            break;

        case 8: // acrescimo ou desconto no subtotal do cupom - ESC 104
            GeraArquivoComando("\x1b|104|A|1000|\x1b"); // acrescimo de 10%
            break;

        case 9: // cancela acrescimo ou desconto no subtotal do cupom - ESC 105
            GeraArquivoComando("\x1b|105|A|\x1b");
            break;

        case 10: // totaliza o cupom - ESC 106
            GeraArquivoComando("\x1b|106|\x1b");
            break;

        case 11: // efetua forma de pagamento com parcelamento - ESC 90
            GeraArquivoComando("\x1b|90|01|00000000000200|02|\x1b");
            GeraArquivoComando("\x1b|90|01|00000000001000|02|Descricao opcional.....25...30...35...40...45...50...55...60...65...70...75...80|\x1b");
            break;

        case 12: // termina o fechamento do cupom fiscal - ESC 34
            //GeraArquivoComando("\x1b|34|\x1b");
            sprintf( strComando, "\x1b|34|");  // inicio do protocolo
            sprintf( strComando + strlen( strComando ), "\\%s%s\\%s%s",  NEGRITO_ON, "CLIENTE: ", NEGRITO_OFF, "Nome do cliente" );
            strcat( strComando, LF);
            sprintf( strComando + strlen( strComando ), "\\%s%s\\%s%s\n\n",  NEGRITO_ON, "COMENTARIO: ", NEGRITO_OFF, "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" );
            sprintf( strComando + strlen( strComando ), "\\%s%s\\%s",  EXPANDIDO_ON, "OBRIGADO E VOLTE SEMPRE", EXPANDIDO_OFF);
            strcat( strComando, "|\x1b");      // fim do protocolo
            GeraArquivoComando( strComando );
            break;
    } // fim do switch

    if ( Opcao > 0 && Opcao < 12 )
        LeRetornoImpressora(0);

    }while( Opcao != 0 );
}


void RelatoriosFiscais( void )
{
    int  Opcao = 0;
    int  Retorno[4];
    int  RetFunction = 0;
    char Var[3000];
    char Aux;

    do
    {
	memset(Var,  '\x0',3000);
	Retorno[0] = 0; Retorno[1] = 0; Retorno[2] = 0; Retorno[3] = 0;
	system("clear");

	printf("                         Comandos dos Relatorios Fiscais\n");

	printf("\n [ 1 ] - Leitura X                                     " );
	printf("\n [ 2 ] - Reducao Z                                     " );
	printf("\n [ 3 ] - Leitura Memoria Fiscal por Data               " );
	printf("\n [ 4 ] - Leitura da Memoria Fiscal por Reducao         " );
	printf("\n [ 5 ] - Leitura Memoria Fiscal por Data pela Serial   " );
	printf("\n [ 6 ] - Leitura Memoria Fiscal por Reducao pela Serial" );
	printf("\n [ 7 ] - Leitura X pela serial                         " );
	printf("\n [ 0 ] - Sair" );

	printf("\n\n Digite a Opcao: " );

	scanf( "%d", &Opcao);
	switch( Opcao )
	{
	    case 1: // leitura X - ESC 06
		GeraArquivoComando("\x1b|06|\x1b");
            	break;

	    case 2: // reducao Z ESC - 05
		GeraArquivoComando("\x1b|05|\x1b");
            	break;

	    case 3: // leitura da mem. fiscal por data ESC - 08
	        GeraArquivoComando("\x1b|08|30|11|01|30|11|01|I|\x1b");
            	break;

	    case 4: // leitura da mem. fiscal por reducao ESC - 08
		GeraArquivoComando("\x1b|08|0|0|0001|0|0|0002|I|\x1b");
            	break;

	    case 5: // leitura da mem. fiscal por data pela serial ESC - 08
		GeraArquivoComando("\x1b|08|30|11|01|30|11|01|R|\x1b");
	        // le o status e o retorno de informacoes dos arquivos
		// status.txt e retorno.txt criados pelo bemafilx.out
	        LeRetornoImpressora(2);
            	break;

	    case 6: // leitura da mem. fiscal por reducao pela serial ESC - 08
		GeraArquivoComando("\x1b|08|0|0|0001|0|0|0002|R|\x1b");
	        // le o status e o retorno de informacoes dos arquivos
		// status.txt e retorno.txt criados pelo bemafilx.out
	        LeRetornoImpressora(2);
            	break;

	    case 7: // leitura X pela serial ESC - 69
		GeraArquivoComando("\x1b|69|\x1b");
	        // le o status e o retorno de informacoes dos arquivos
		// status.txt e retorno.txt criados pelo bemafilx.out
	        LeRetornoImpressora(2);
            	break;

	} // fim do switch

	if ( Opcao != 0 && Opcao < 5 )
	{
	   // le o status e o retorno de informacoes dos arquivos status.txt e
	   // retorno.txt criados pelo bemafilx.out
	   LeRetornoImpressora(0);
	}
    }
    while( Opcao != 0 );
}

void OperacoesNaoFiscais( void )
{
    int  Opcao = 0;
    int  Retorno[4];
    int  RetFunction = 0;
    char Var[3000];
    char Aux;

    do
    {
	memset(Var,  '\x0',3000);
	Retorno[0] = 0; Retorno[1] = 0; Retorno[2] = 0; Retorno[3] = 0;

	system("clear");

	printf("                       Comandos das Operacoes Nao Fiscais\n");

	printf("\n [  1 ] - Comprovante de Credito e Debito...    " );
	printf("\n [  2 ] - Recebimento nao Fiscal                " );
	printf("\n [  3 ] - Recebimento nao Fiscal MFD...         " );
	printf("\n [  4 ] - Relatorio Gerencial                   " );
	printf("\n [  5 ] - Abre Relatorio Gerencial MFD          " );
	printf("\n [  6 ] - Imprime Relatorio Gerencial MFD       " );
	printf("\n [  7 ] - Aciona Guilhotina (corte parcial)     " );
	printf("\n [  8 ] - Imprime Codigo Barras MFD             " );
	printf("\n [  9 ] - Fecha Relatorio Gerencial             " );
	printf("\n [ 10 ] - Suprimento                            " );
	printf("\n [ 11 ] - Sangria                               " );
	printf("\n [  0 ] - Sair" );

	printf("\n\n Digite a Opcao: " );

	scanf( "%d", &Opcao);
	switch( Opcao )
	{
	    case 1: // Comprovantes de Credito e Debito
			ComprovanteCreditoDebito();
            break;

	    case 2: // Recebimento nao fiscal
			GeraArquivoComando("\x1b|25|01|00000000010000|\x1b");
            break;

	    case 3: // operacoes de recebimento nao fiscal MFD
			Recebimentos();
            break;

	    case 4: // Relatorio gerencial - ESC 20
			GeraArquivoComando("\x1b|20|As informacoes do relatorio gerencial devem ser impressas aqui.|\x1b");
            break;

	    case 5: // Abre relatorio gerencial MFD  ESC - 83
			GeraArquivoComando("\x1b|83|01|\x1b");
            break;

	    case 6: // Imprime relatorio gerencial ESC - 67
			GeraArquivoComando("\x1b|67|As informacoes do relatorio gerencial devem ser impressas aqui.|\x1b");
			break;

	    case 7: // Aciona guilhotina (corte parcial)
	    {
    		char strComando[30];
			//sprintf(strComando, "\x1b|67|%s%s|\x1b", "\\", CORTE_TOTAL);
			sprintf(strComando, "\x1b|67|%s%s|\x1b", "\\", CORTE_PARCIAL);
			GeraArquivoComando(strComando);
			break;
		}

	    case 8: // imprime codigo de barras no relatorio gerencial
			CodigoBarras();
            break;

	    case 9: // fecha relatorio gerencial ESC - 21
			GeraArquivoComando("\x1b|21|\x1b");
            break;

	    case 10: // suprimento ESC - 25
			GeraArquivoComando("\x1b|25|SU|00000000010000|\x1b");
            break;

	    case 11: // sangria ESC - 25
			GeraArquivoComando("\x1b|25|SA|00000000001000|\x1b");
            break;

	} // fim do switch

	if ( Opcao != 1 && Opcao != 3 && Opcao != 8)
	{
		if ( Opcao != 0 && Opcao < 11 )
		{
	   		// le o status e o retorno de informacoes dos arquivos status.txt e
	   		// retorno.txt criados pelo bemafilx.out
	   		LeRetornoImpressora(0);
		}
    }
    }
    while( Opcao != 0 );

}
void Recebimentos( void )
{
    int  Opcao = 0;
    int  Retorno[4];
    int  RetFunction = 0;
    char Var[3000];
    char Aux;

    do
    {
	memset(Var,  '\x0',3000);
	Retorno[0] = 0; Retorno[1] = 0; Retorno[2] = 0; Retorno[3] = 0;

	system("clear");

	printf("                       Comandos dos Recebimentos Nao Fiscais\n");

	printf("\n [  1 ] - Abre Recebimento nao Fiscal           " );
	printf("\n [  2 ] - Efetua Recebimento nao Fiscal         " );
	printf("\n [  3 ] - Acrescimo/Desconto no Recebimento nao Fiscal   " );
	printf("\n [  4 ] - Cancela Acrescimo/Desconto no Recebimento nao Fiscal" );
	printf("\n [  5 ] - Cancela Recebimento nao Fiscal        " );
	printf("\n [  6 ] - Inicia Fechamento Recebimento nao fiscal");
	printf("\n [  7 ] - Subtotaliza Recebimento nao fiscal     " );
	printf("\n [  8 ] - Acrescimo e Desconto em Subtotal de Recebimento" );
	printf("\n [  9 ] - Cancela Acrescimo e Desconto em Subtotal de Recebimento" );
	printf("\n [ 10 ] - Totaliza Recebimento nao Fiscal" );
	printf("\n [ 11 ] - Efetua Forma de Pagamento             " );
	printf("\n [ 12 ] - Fecha Recebimento nao Fiscal          " );
	printf("\n [ 13 ] - Cancela Cupom de Recebimento Nao Fiscal        " );
	printf("\n [  0 ] - Sair" );

	printf("\n\n Digite a Opcao: " );

	scanf( "%d", &Opcao);
	switch( Opcao )
	{
	    case 1: // Abre recebimento nao fiscal MFD - ESC 77
			GeraArquivoComando("\x1b|77|12345678901234567890123456789|Nome do cliente|Endereco do cliente|\x1b");
            break;

	    case 2: // Efetua recebimento nao fiscal - ESC 78
			GeraArquivoComando("\x1b|78|01|00000000001000|\x1b");
            break;

	    case 3: // Acrescimo/desconto no recebimento nao fiscal - ESC 117
			GeraArquivoComando("\x1b|117|A|001|00000100|\x1b");
            break;

	    case 4: // Cancelamento do acrescimo/desconto no recebimento nao fiscal - ESC 118
			GeraArquivoComando("\x1b|118|A|001|\x1b");
            break;

	    case 5: // Cancela item recebimento nao fiscal - ESC 116
			GeraArquivoComando("\x1b|116|001|\x1b");
            break;

	    case 6: // Inicia fechamento do recebimento nao fiscal
	            // com acrescimo e desconto percentual MFD - ESC 79
			GeraArquivoComando("\x1b|79|T|0500|1000|\x1b");
            break;

	    case 7: // Subtotaliza recebimento nao fiscal - ESC 107
			GeraArquivoComando("\x1b|107|\x1b");
            break;

	    case 8: // Acrescimo ou desconto em subtotal de recebimento - ESC 108
			GeraArquivoComando("\x1b|108|D|1000|\x1b");
            break;

	    case 9: // Cancela acrescimo ou desconto em subtotal de recebimento - ESC 109
			GeraArquivoComando("\x1b|109|D|\x1b");
            break;

	    case 10: // Totaliza recebimento nao fiscal - ESC 110
			GeraArquivoComando("\x1b|110|\x1b");
            break;

	    case 11: // Efetua forma de pagamento com parcelamento - ESC 90
			GeraArquivoComando("\x1b|90|01|00000000050000|02|\x1b");
            break;

	    case 12: // Fecha recebimento nao fiscal - ESC 34
			GeraArquivoComando("\x1b|34|Obrigado e volte sempre|\x1b");
            break;

	    case 13: // Cancela recebimento nao fiscal MFD - ESC 81
			GeraArquivoComando("\x1b|81|12345678901234567890123456789|Nome do cliente|Endereco do cliente|\x1b");
            break;

	} // fim do switch

	if ( Opcao != 0 && Opcao < 14)
	{
	   // le o status e o retorno de informacoes dos arquivos status.txt e
	   // retorno.txt criados pelo bemafilx.out
	   LeRetornoImpressora(0);
	}
    }
    while( Opcao != 0 );

}

void ComprovanteCreditoDebito( void )
{
    int  Opcao = 0;
    int  Retorno[4];
    int  RetFunction = 0;
    char Var[3000];
    char Aux;
    char strComando[500];

    do
    {
	memset(Var,  '\x0',3000);
	Retorno[0] = 0; Retorno[1] = 0; Retorno[2] = 0; Retorno[3] = 0;

	system("clear");

	printf("                   Comprovante de Credito e Debito (CNFV)\n");

	printf("\n [  1 ] - Abre Comprovante de Credito e Debito (Vinculado)     " );
	printf("\n [  2 ] - Imprime Comprovante de Credito e Debito (Vinculado)  " );
	printf("\n [  3 ] - Aciona Guilhotina (corte parcial)                    " );
    printf("\n [  4 ] - Avanca Linha e Corta o Papel MFD                     " );
    printf("\n [  5 ] - Imprime Codigo Barras MFD                            " );
	printf("\n [  6 ] - Fecha Comprovante de Credito e Debito (Vinculado)    " );
	printf("\n [  7 ] - Reimprime Comprovante de Credito e Debito MFD        " );
	printf("\n [  8 ] - Abre Segunda Via Comprovante de Credito e Debito MFD " );
    printf("\n [  9 ] - Segunda Via Comprovante de Credito e Debito MFD      " );
	printf("\n [ 10 ] - Estorno Comprovante de Credito e Debito MFD          " );
    printf("\n [ 11 ] - Estorno Comprovante de Credito e Debito Posterior MFD" );
    printf("\n [  0 ] - Sair" );

	printf("\n\n Digite a Opcao: " );

	scanf( "%d", &Opcao);
	switch( Opcao )
	{
	    case 1: // Abre comprovante de credito e debito - ESC 66

            // emite o cupom fiscal para permitir a emissao do CDC
            EmitirCupomFiscal();

            GeraArquivoComando("\x1b|66|Cartao          |\x1b");
            break;

	    case 2: // Imprime comprovante de credito e debito - ESC 67
			GeraArquivoComando("\x1b|67|Texto do comprovante de credito e debito|\x1b");
            break;

	    case 3: // Aciona guilhotina (corte parcial)
	    {
    		char strComando[30];
			//sprintf(strComando, "\x1b|67|%s%s|\x1b", "\\", CORTE_TOTAL);
			sprintf(strComando, "\x1b|67|%s%s|\x1b", "\\", CORTE_PARCIAL);
			GeraArquivoComando(strComando);
			break;
		}

        case 4: // Avanca linha e corta o papel - ESC 62 75
            GeraArquivoComando("\x1b|62|75|5|2|\x1b"); // avanca 5 linhas sem corte
            GeraArquivoComando("\x1b|62|75|5|1|\x1b"); // avanca 5 linhas corte parcial
            GeraArquivoComando("\x1b|62|75|5|0|\x1b"); // avanca 5 linhas corte total
            break;

        case 5: // Imprime codigo de barras no vinculado ou gerencial
			CodigoBarras();
            break;

	    case 6: // Fecha comprovante de credito e debito - ESC 21
			GeraArquivoComando("\x1b|21|\x1b");
            break;

	    case 7: // Reimprime comprovante de credito e debito - ESC 92
			GeraArquivoComando("\x1b|92|\x1b");
            break;

        case 8: // Abre segunda via do comprovante de credito e debito - ESC 91
            GeraArquivoComando("\x1b|62|84|\x1b");
            break;

	    case 9: // Segunda via do comprovante de credito e debito - ESC 91
			GeraArquivoComando("\x1b|91|\x1b");
            break;

	    case 10: // Estorno de comprovante de credito e debito - ESC 102
			GeraArquivoComando("\x1b|102|12345678901234567890123456789|Nome do cliente|Endereco do cliente|\x1b");
            // apos o comando de estorno tem que chamar o comando de fechamento
            GeraArquivoComando("\x1b|21|\x1b");
            break;

        case 11: // Estorno de comprovante de credito e debito posterior - ESC 75
            EstornoCDCPosterior();
            LeRetornoImpressora(0);
			// apos o comando de estorno tem que chamar o comando de fechamento
			GeraArquivoComando("\x1b|21|\x1b");
            break;

    } // fim do switch

	if ( Opcao != 5 && ( Opcao > 0 && Opcao < 11 ) )
	{
	   // le o status e o retorno de informacoes dos arquivos status.txt e
	   // retorno.txt criados pelo bemafilx.out
	   LeRetornoImpressora(0);
	}
    }while( Opcao != 0 );

}

void InformacoesImpressora( void )
{
    int  Opcao = 0;
    int  Retorno[4];
    int  RetFunction = 0;
    char Var[3000];
    char Aux;

    do
    {
	memset(Var,  '\x0',3000);
	Retorno[0] = 0; Retorno[1] = 0; Retorno[2] = 0; Retorno[3] = 0;

	system("clear");

	printf("                       Comandos de Informacoes da Impressora\n");

	printf("\n [  1 ] - Leitura do Estado da Impressora        " );
	printf("\n [  2 ] - Leitura das Aliquotas                  " );
	printf("\n [  3 ] - Leitura dos Totalizadores Parciais     " );
	printf("\n [  4 ] - Leitura dos Totalizadores Parciais MFD " );
	printf("\n [  5 ] - SubTotal                               " );
	printf("\n [  6 ] - Numero do Cupom                        " );
	printf("\n [  7 ] - Monitoramento do Papel                 " );
	printf("\n [  8 ] - Dados da Ultima Reducao Z              " );
	printf("\n [  9 ] - Dados da Ultima Reducao Z MFD          " );
	printf("\n [ 10 ] - Retorno de Informacoes                 " );
	printf("\n [ 11 ] - Retorno de Informacoes MFD - 35|40 a 35|75" );
    printf("\n [ 12 ] - Retorno de Informacoes MFD - 35|76 a 35|81" );
	printf("\n [  0 ] - Sair" );

	printf("\n\n Digite a Opcao: " );

	scanf( "%d", &Opcao);
	switch( Opcao )
	{
	    case 1: // leitura do estado da impressora - ESC 19
		GeraArquivoComando("\x1b|19|\x1b");
	   	LeRetornoImpressora(3);
            	break;

	    case 2: // leitura da aliquotas cadastradas - ESC 26
		GeraArquivoComando("\x1b|26|\x1b");
            	break;

	    case 3: // leitura dos totalizadadores parciais - ESC 27
		GeraArquivoComando("\x1b|27|\x1b");
            	break;

	    case 4: // leitura dos totalizadadores parciais MFD - ESC 87
		GeraArquivoComando("\x1b|87|\x1b");
            	break;

	    case 5: // leitura do subtotal do cupom - ESC 29
		GeraArquivoComando("\x1b|29|\x1b");
            	break;

	    case 6: // leitura do numero do cupom - ESC 30
		GeraArquivoComando("\x1b|30|\x1b");
            	break;

	    case 7: // leitura do estado do papel - ESC 62 54
		GeraArquivoComando("\x1b|62|54|\x1b");
            	break;

	    case 8: // leitura dos dados da ultima reducao - ESC 62 55
		GeraArquivoComando("\x1b|62|55|\x1b");
            	break;

	    case 9: // leitura dos dados da ultima reducao MFD - ESC 88
		GeraArquivoComando("\x1b|88|\x1b");
            	break;

	    case 10:
		RetornoVariaveis();
            	break;

	    case 11:
		RetornoVariaveisMFD();
            	break;

        case 12:
        RetornoVariaveis2MFD();
                break;

	} // fim do switch

	if ( Opcao > 1 && Opcao < 10 )
	{
	   // le o status e o retorno de informacoes dos arquivos status.txt e
	   // retorno.txt criados pelo bemafilx.out
	   LeRetornoImpressora(1);
	}
    }
    while( Opcao != 0 );

}

void GavetaAutenticacao( void )
{
    int  Opcao = 0;
    int  Retorno[4];
    int  RetFunction = 0;
    char Var[3000];
    char Aux;

    do
    {
	memset(Var,  '\x0',3000);
	Retorno[0] = 0; Retorno[1] = 0; Retorno[2] = 0; Retorno[3] = 0;

	system("clear");

	printf("                     Comandos da Gaveta e Autenticacao\n");

	printf("\n [ 1 ] - Aciona Gaveta                         " );
	printf("\n [ 2 ] - Status da Gaveta                      " );
	printf("\n [ 3 ] - Autenticacao                          " );
	printf("\n [ 4 ] - Programa Caracter para Autenticacao   " );
	printf("\n [ 0 ] - Sair" );

	printf("\n\n Digite a Opcao: " );

	scanf( "%d", &Opcao);
	switch( Opcao )
	{
	    case 1: // abertura da gaveta de dinheiro
		GeraArquivoComando("\x1b|22|\x1b");
            	break;

	    case 2: // leitura do estado da gaveta
		GeraArquivoComando("\x1b|23|\x1b");
		LeRetornoImpressora(1);
                break;

	    case 3: // autenticacao de documentos
		GeraArquivoComando("\x1b|16|\x1b");
                break;

	    case 4: // programa caracter para autenticacao
		GeraArquivoComando("\x1b|64|001|002|004|008|016|032|064|128|064|032|016|008|004|002|001|129|129|129|\x1b");
                break;

	} // fim do switch

	if ( Opcao != 2 && Opcao != 0 && Opcao < 5 )
	{
	   // le o status e o retorno de informacoes dos arquivos status.txt e
	   // retorno.txt criados pelo bemafilx.out
	   LeRetornoImpressora(0);
	}
    }
    while( Opcao != 0 );

}

void ImpressaoCheque( void )
{
    int  Opcao = 0;
    int  Retorno[4];
    int  RetFunction = 0;
    char Var[3000];
    char Aux;
    BOOL leRetorno = TRUE;

    do
    {
	memset(Var,  '\x0',3000);
	Retorno[0] = 0; Retorno[1] = 0; Retorno[2] = 0; Retorno[3] = 0;

	system("clear");

	printf("                       Comandos de Impressao de Cheques\n");
	printf("\n [  1 ] - Status do Cheque           " );
    printf("\n [  2 ] - Leitura do Cheque          " );
    printf("\n [  3 ] - Leitura do Cheque MFD      " );
    printf("\n [  4 ] - Programa Moeda no Singular " );
    printf("\n [  5 ] - Programa Moeda no Plural   " );
    printf("\n [  6 ] - Cancela Impressao do Cheque" );
	printf("\n [  7 ] - Imprime Cheque             " );
	printf("\n [  8 ] - Imprime Cheque MFD         " );
    printf("\n [  9 ] - Imprime Cheque 80 carac. no Favorecido e 240 na mensagem MFD" );
    printf("\n [ 10 ] - Imprime Informacao Adicional no Cheque MFD" );
    printf("\n [ 11 ] - Virar o cheque MFD" );
    printf("\n [  0 ] - Sair" );

	printf("\n\n Digite a Opcao: " );

	leRetorno = TRUE;
    scanf( "%d", &Opcao);
	switch( Opcao )
	{
        case 1: // leitura do status do cheque - ESC 62 48
            GeraArquivoComando("\x1b|62|48|\x1b");
            LeRetornoImpressora(1);
            leRetorno = FALSE;
            break;


        case 2: // leitura do cheque
            GeraArquivoComando("\x1b|76|\x1b");

            // le o status e o retorno de informacoes dos arquivos status.txt e
            // retorno.txt criados pelo bemafilx.out
            LeRetornoImpressora(1);
            leRetorno = FALSE;

            // Apos a leitura do CMC7, o cheque fica preso aguardando a impressao.
            // Para liberar o cheque deve-se fazer a impressao ou executar o comando
            // de cancelamento da impressao
            GeraArquivoComando("\x1b|62|49|\x1b");
            break;

        case 3: // leitura do cheque MFD (leitura do codigo CMC7)

            // para as impressoras MFD o comando possue um parâmetro a mais
            // que indica se o cheque será virado ou não apos a leitura do CMC7
            // 0 - vira o cheque, 1 - nao vira o cheque  apos a leitura

            // para fazer a leitura do código CMC7 o cheque deve ser posicionado
            // de cabeca para baixo, o parametro de virar o cheque faz com que
            // apos a leitura do CMC7 o cheque seja virado e posicionado para a
            // impressao
            GeraArquivoComando("\x1b|76|1|\x1b");

            // le o status e o retorno de informacoes dos arquivos status.txt e
            // retorno.txt criados pelo bemafilx.out
            LeRetornoImpressora(1);
            leRetorno = FALSE;

            // Apos a leitura do CMC7, o cheque fica preso aguardando a impressao.
            // Para liberar o cheque deve-se fazer a impressao ou executar o comando
            // de cancelamento da impressao
            GeraArquivoComando("\x1b|62|49|\x1b");
            break;

        case 4: // programa moeda no singular - ESC 58
            GeraArquivoComando("\x1b|58|Real               |\x1b");
            break;

	    case 5: // programa moeda no plural - ESC 59
            GeraArquivoComando("\x1b|59|Reais                 |\x1b");
            break;

	    case 6: // cancela impressao do cheque - ESC 62 49
		GeraArquivoComando("\x1b|62|49|\x1b");
            	break;

	    case 7: // impressao de cheque - ESC 57
            GeraArquivoComando("\x1b|57|001|00000000015000|Bematech S/A                                 |Curitiba                   |30|11|2001|\x1b");
            break;

	    case 8: // impressao de cheque MFD - ESC 94
            GeraArquivoComando("\x1b|94|1|0|001|00000000015000|Bematech                                     |Curitiba                   |23|11|2006|\x1b");
            break;

        case 9: // impressao de cheque com 80 carac. favorecido e 240 carac na mensagem MFD - ESC 62 76
            GeraArquivoComando("\x1b|62|76|001|00000000015000|Bematech.....15...20...25...30...35...40...45...50...55...60...65...70...75...80|Curitiba.....15...20.....27|03|10|2009|0|Mensagem ate 240 caracteres.30...35...40...45...50...55...60...65...70...75...80...85...90...95..100..105..110..115..120..125..130..135..140..145..150..155..160..165..170..175..180..185..190..195..200..205..210..215..220..225..230..235..240|\x1b");
            break;

        case 10: // imprime informacao adicional no cheque MFD - ESC 120
            GeraArquivoComando("\x1b|120|1|03|Mensagem ate 240 caracteres.30...35...40...45...50...55...60...65...70...75...80...85...90...95..100..105..110..115..120..125..130..135..140..145..150..155..160..165..170..175..180..185..190..195..200..205..210..215..220..225..230..235..240|\x1b");
            break;

        case 11: // Virar o cheque - ESC 62 77
            // vira o cheque para impressão no verso;
            GeraArquivoComando("\x1b|62|77|\x1b");
            LeRetornoImpressora(0);
            leRetorno = FALSE;

            // para liberar o cheque é necessário fazer alguma impressao
            // ou enviar o comando de cancelamento do cheque
            GeraArquivoComando("\x1b|62|49|\x1b");
            break;

    } // fim do switch

	//if ( Opcao > 2 && Opcao != 0 && Opcao < 11 )
    if ( Opcao != 0 && leRetorno )
    {
	   // le o status e o retorno de informacoes dos arquivos status.txt e
	   // retorno.txt criados pelo bemafilx.out
	   LeRetornoImpressora(0);
	}
    }
    while( Opcao != 0 );

}

void RetornoVariaveis( void )
{
    int  Opcao = 0;
    int  Retorno[4];
    int  RetFunction = 0;
    char Var[3000];
    char Aux;

    do
    {
	memset(Var,  '\x0',3000);
	Retorno[0] = 0; Retorno[1] = 0; Retorno[2] = 0; Retorno[3] = 0;

	system("clear");

	printf("                       Retorno de Informacoes - Comando 35 \n");

	printf("\n [  1 ] - Numero de Serie               [ 19 ] - Minutos Ligada");
	printf("\n [  2 ] - Versao do Firmware            [ 20 ] - Minutos Imprimindo             ");
	printf("\n [  3 ] - CGC/IE                        [ 21 ] - Flag de Intervencao Tecnica    ");
	printf("\n [  4 ] - Grande Total                  [ 22 ] - Flag de Eprom Conectada        ");
	printf("\n [  5 ] - Cancelamentos                 [ 23 ] - Valor Pago no Ultimo Cupom     ");
	printf("\n [  6 ] - Descontos                     [ 24 ] - Data e Hora                    ");
	printf("\n [  7 ] - Contador Sequencial           [ 25 ] - Contadores Totaliz. Nao Fiscais");
	printf("\n [  8 ] - Num. Operacoes Nao Fiscais    [ 26 ] - Descricao Totaliz. Nao Fiscais ");
	printf("\n [  9 ] - Numero Cupons Cancelados      [ 27 ] - Data da Ultima Reducao Z       ");
	printf("\n [ 10 ] - Numero de Reducoes            [ 28 ] - Data do Movimento              ");
	printf("\n [ 11 ] - Num. Intervencoes Tecnicas    [ 29 ] - Flag de Truncamento            ");
	printf("\n [ 12 ] - Num. Subst. Proprietario      [ 30 ] - Flag de Vinculacao ao ISS      ");
	printf("\n [ 13 ] - Numero Ultimo Item Vendido    [ 31 ] - Acrescimos                     ");
	printf("\n [ 14 ] - Cliche do Proprietario        [ 32 ] - Contador de Bilhete de Passagem");
	printf("\n [ 15 ] - Numero do Caixa               [ 33 ] - Leitura das Formas de Pagamento");
	printf("\n [ 16 ] - Numero da Loja                [ 34 ] - Leitura dos Recebimentos(CNFNV)");
	printf("\n [ 17 ] - Moeda                         [ 35 ] - Leitura dos Departamentos      ");
	printf("\n [ 18 ] - Flags Fiscais                 [ 36 ] - Tipo da Impressora             ");

	printf("\n\n [ 0 ] - Sair" );

	printf("\n\n Digite a Opcao: " );

	scanf( "%d", &Opcao);
	switch( Opcao )
	{
	    case 1: // numero de serie  - ESC 35 40
		GeraArquivoComando("\x1b|35|00|\x1b");
            	break;

	    case 2: // versao do firmware - ESC 35 01
		GeraArquivoComando("\x1b|35|01|\x1b");
            	break;

	    case 3: // CGC/IE - ESC 35 02
		GeraArquivoComando("\x1b|35|02|\x1b");
            	break;

	    case 4: // grande total - ESC 35 03
		GeraArquivoComando("\x1b|35|03|\x1b");
            	break;

	    case 5: // cancelamentos - ESC 35 04
		GeraArquivoComando("\x1b|35|04|\x1b");
            	break;

	    case 6: // descontos - ESC 35 05
		GeraArquivoComando("\x1b|35|05|\x1b");
            	break;

	    case 7: // contador sequencial - ESC 35 06
		GeraArquivoComando("\x1b|35|06|\x1b");
            	break;

	    case 8: // numero e operacoes fiscais - ESC 35 07
		GeraArquivoComando("\x1b|35|07|\x1b");
            	break;

	    case 9: // cupons cancelados - ESC 35 08
		GeraArquivoComando("\x1b|35|08|\x1b");
            	break;

	    case 10: // numero de reducoes - ESC 35 09
		GeraArquivoComando("\x1b|35|09|\x1b");
            	break;

	    case 11: // numero de intervencoes tecnicas - ESC 35 10
		GeraArquivoComando("\x1b|35|10|\x1b");
            	break;

	    case 12: // numero de substituicoes de proprietario - ESC 35 11
		GeraArquivoComando("\x1b|35|11|\x1b");
            	break;

	    case 13: // ultimo item vendido - ESC 35 12
		GeraArquivoComando("\x1b|35|12|\x1b");
            	break;

	    case 14: // cliche do proprietario - ESC 35 13
		GeraArquivoComando("\x1b|35|13|\x1b");
            	break;

	    case 15: // numero do caixa - ESC 35 14
		GeraArquivoComando("\x1b|35|14|\x1b");
            	break;

	    case 16: // numero da loja - ESC 35 15
		GeraArquivoComando("\x1b|35|15|\x1b");
            	break;

	    case 17: // moeda - ESC 35 16
		GeraArquivoComando("\x1b|35|16|\x1b");
            	break;

	    case 18: // flags fiscais - ESC 35 17
		GeraArquivoComando("\x1b|35|17|\x1b");
            	break;

	    case 19: // minutos ligada - ESC 35 18
		GeraArquivoComando("\x1b|35|18|\x1b");
            	break;

	    case 20: // minutos imprimindo - ESC 35 19
		GeraArquivoComando("\x1b|35|19|\x1b");
            	break;

	    case 21: // intervencao tecnica - ESC 35 20
		GeraArquivoComando("\x1b|35|20|\x1b");
            	break;

	    case 22: // flag de eprom conectada - ESC 35 21
		GeraArquivoComando("\x1b|35|21|\x1b");
            	break;

	    case 23: // valor pago no ultimo cupom - ESC 35 22
		GeraArquivoComando("\x1b|35|22|\x1b");
            	break;

	    case 24: // data e hora - ESC 35 23
		GeraArquivoComando("\x1b|35|23|\x1b");
            	break;

	    case 25: // contadores dos tot. nao fiscais - ESC 35 24
		GeraArquivoComando("\x1b|35|24|\x1b");
            	break;

	    case 26: // descricao dos totalizadores fiscais - ESC 35 25
		GeraArquivoComando("\x1b|35|25|\x1b");
            	break;

	    case 27: // data da ultima reducao - ESC 35 26
		GeraArquivoComando("\x1b|35|26|\x1b");
            	break;

	    case 28: // data do movimento - ESC 35 27
		GeraArquivoComando("\x1b|35|27|\x1b");
            	break;

	    case 29: // verifica truncamento - ESC 35 28
		GeraArquivoComando("\x1b|35|28|\x1b");
            	break;

	    case 30: // flags de vinculacao ao ISS - ESC 35 29
		GeraArquivoComando("\x1b|35|29|\x1b");
            	break;

	    case 31: // acrescimos - ESC 35 30
		GeraArquivoComando("\x1b|35|30|\x1b");
            	break;

	    case 32: // contador de bilhete de passagem - ESC 35 31 (somente
	             // para a impressora de bilhete de passagem rodoviaria)
		GeraArquivoComando("\x1b|35|31|\x1b");
            	break;

	    case 33: // leitura das formas de pagto - ESC 35 32
		GeraArquivoComando("\x1b|35|32|\x1b");
            	break;

	    case 34: // leitura dos receb. nao fiscais - ESC 35 33
		GeraArquivoComando("\x1b|35|33|\x1b");
            	break;

	    case 35: // leitura dos departamentos - ESC 35 34
		GeraArquivoComando("\x1b|35|34|\x1b");
            	break;

	    case 36: // tipo da impressora - ESC 35 253
		GeraArquivoComando("\x1b|35|253|\x1b");
            	break;

	} // fim do switch

	if ( Opcao > 0 && Opcao < 37 )
	{
	   // le o status e o retorno de informacoes dos arquivos status.txt e
	   // retorno.txt criados pelo bemafilx.out
	   LeRetornoImpressora(1);
	}
    }
    while( Opcao != 0 );
}

void RetornoVariaveisMFD( void )
{
    int  Opcao = 0;
    int  Retorno[4];
    int  RetFunction = 0;
    char Var[3000];
    char Aux;

    do
    {
	memset(Var,  '\x0',3000);
	Retorno[0] = 0; Retorno[1] = 0; Retorno[2] = 0; Retorno[3] = 0;

	system("clear");

	printf("                       Retorno de Informacoes MFD - Comando 35\n");

	printf("\n [  1 ] - Numero de Serie               [ 19 ] - Numero de Serie da MFD         ");
	printf("\n [  2 ] - Versao do Firmware            [ 20 ] - Num. Reducoes Restantes        ");
	printf("\n [  3 ] - CNPJ                          [ 21 ] - Marca, Modelo e Tipo           ");
	printf("\n [  4 ] - Inscricao Estadual            [ 22 ] - Percentual de MFD Livre        ");
	printf("\n [  5 ] - Inscricao Municipal           [ 23 ] - Tamanho Total da MFD em Bytes  ");
	printf("\n [  6 ] - Tempo Operacional em Minutos  [ 24 ] - Tamanho da MFD Livre em Bytes  ");
	printf("\n [  7 ] - Minutos Emitindo Documentos   [ 25 ] - Data/Hora Ult. Doc. Armazenado ");
	printf("\n [  8 ] - Cont. Tot. nao Fiscais        [ 26 ] - Flags Fiscais II               ");
	printf("\n [  9 ] - Descricao Tot. nao Fiscais    [ 27 ] - Subtotal de Comprov. nao Fiscal");
	printf("\n [ 10 ] - Formas de Pagamento           [ 28 ] - Data Movimento Ultima Reducao  ");
	printf("\n [ 11 ] - Totalizadores nao Fiscais     [ 29 ] - Grande Total Ultima Reducao    ");
	printf("\n [ 12 ] - Relatorios Gerenciais         [ 30 ] - UF do Usuario                  ");
	printf("\n [ 13 ] - Cont. Comprov. Credito/Debito [ 31 ] - Tempo Restante do Vinc/Gerencia");
	printf("\n [ 14 ] - Cont. Oper. nao fiscais Canc. [ 32 ] - COO Inicial/Final Ultima Reduc ");
	printf("\n [ 15 ] - Cont. Relatorios Gerenciais   [ 33 ] - GT Inicial/Final Ultima Reducao");
	printf("\n [ 16 ] - Cont. Cupom Fiscal            [ 34 ] - Flag Corte Proximo Documento   ");
	printf("\n [ 17 ] - Cont. Fita Detalhe            [ 35 ] - Flag Alinhamento Descricao     ");
	printf("\n [ 18 ] - Cont. Credit/Debit nao Emitid                                         ");

	printf("\n\n [ 0 ] - Sair" );

	printf("\n\n Digite a Opcao: " );

	scanf( "%d", &Opcao);
	switch( Opcao )
	{
	    case 1: // numero de serie MFD - ESC 35 40
		GeraArquivoComando("\x1b|35|40|\x1b");
            	break;

	    case 2: // versao do firmware MFD - ESC 35 41
		GeraArquivoComando("\x1b|35|41|\x1b");
            	break;

	    case 3: // CNPJ - ESC 35 42
		GeraArquivoComando("\x1b|35|42|\x1b");
            	break;

	    case 4: // Inscricao Estadual - ESC 35 43
		GeraArquivoComando("\x1b|35|43|\x1b");
            	break;

	    case 5: // Inscricao Municipal - ESC 35 44
		GeraArquivoComando("\x1b|35|44|\x1b");
            	break;

	    case 6: // Tempo Operacional - ESC 35 45
		GeraArquivoComando("\x1b|35|45|\x1b");
            	break;

	    case 7: // Minutos emitindo documentos fiscais - ESC 35 46
		GeraArquivoComando("\x1b|35|46|\x1b");
            	break;

	    case 8: // contadores dos totalizadores nao fiscais - ESC 35 47
		GeraArquivoComando("\x1b|35|47|\x1b");
            	break;

	    case 9: // descricao dos totalizadores nao fiscais - ESC 35 48
		GeraArquivoComando("\x1b|35|48|\x1b");
            	break;

	    case 10: // formas de pagamento - ESC 35 49
		GeraArquivoComando("\x1b|35|49|\x1b");
            	break;

	    case 11: // totalizadores nao fiscais - ESC 35 50
		GeraArquivoComando("\x1b|35|50|\x1b");
            	break;

	    case 12: // relatorios gerenciais - ESC 35 51
		GeraArquivoComando("\x1b|35|51|\x1b");
            	break;

	    case 13: // contador de comprovante de credito e debito - ESC 35 52
		GeraArquivoComando("\x1b|35|52|\x1b");
            	break;

	    case 14: // contador de operacoes nao fiscais canceladas - ESC 35 53
		GeraArquivoComando("\x1b|35|53|\x1b");
            	break;

	    case 15: // contador de relatorios gerenciais - ESC 35 54
		GeraArquivoComando("\x1b|35|54|\x1b");
            	break;

	    case 16: // contador de cupom fiscal - ESC 35 55
		GeraArquivoComando("\x1b|35|55|\x1b");
            	break;

	    case 17: // contador de fita detalhe - ESC 35 56
		GeraArquivoComando("\x1b|35|56|\x1b");
            	break;

	    case 18: // contador de comprovantes de credito e debito nao emitios - ESC 35 57
		GeraArquivoComando("\x1b|35|57|\x1b");
            	break;

	    case 19: // numero de serie da MFD - ESC 35 58
		GeraArquivoComando("\x1b|35|58|\x1b");
            	break;

	    case 20: // numero de reducoes restantes - ESC 35 59
		GeraArquivoComando("\x1b|35|59|\x1b");
            	break;

	    case 21: // marca, modelo e tipo - ESC 35 60
		GeraArquivoComando("\x1b|35|60|\x1b");
            	break;

	    case 22: // percentual de MFD livre - ESC 35 61
		GeraArquivoComando("\x1b|35|61|\x1b");
            	break;

	    case 23: // tamanho total da MFD em bytes - ESC 35 62
		GeraArquivoComando("\x1b|35|62|\x1b");
            	break;

	    case 24: // tamanho da MFD livre em bytes - ESC 35 63
		GeraArquivoComando("\x1b|35|63|\x1b");
            	break;

	    case 25: // data e hora do ultimo documento armazenado na mfd - ESC 35 64
		GeraArquivoComando("\x1b|35|64|\x1b");
            	break;

	    case 26: // flags fiscais II - ESC 35 65
		GeraArquivoComando("\x1b|35|65|\x1b");
            	break;

	    case 27: // subtotal do comprovante nao fiscal - ESC 35 66
		GeraArquivoComando("\x1b|35|66|\x1b");
            	break;

	    case 28: // data do movimento da ultima reducao z - ESC 35 67
		GeraArquivoComando("\x1b|35|67|\x1b");
            	break;

	    case 29: // grande total da ultima reducao z - ESC 35 68
		GeraArquivoComando("\x1b|35|68|\x1b");
            	break;

	    case 30: // UF do usuario - ESC 35 69
		GeraArquivoComando("\x1b|35|70|\x1b");
            	break;

	    case 31: // tempo restante para emissao do vinculado ou relatorio gerencial - ESC 35 70
		GeraArquivoComando("\x1b|35|71|\x1b");
            	break;

	    case 32: // COO incial e final da ultima reducao z - ESC 35 71 (somente
		GeraArquivoComando("\x1b|35|72|\x1b");
            	break;

	    case 33: // GT inicial e final da ultima reducao z - ESC 35 72
		GeraArquivoComando("\x1b|35|73|\x1b");
            	break;

	    case 34: // flag de ativacao do corte do proximo documento - ESC 35 73
		GeraArquivoComando("\x1b|35|74|\x1b");
            	break;

	    case 35: // flag de ativacao do alinhamento da descricao a esquerda - ESC 35 74
		GeraArquivoComando("\x1b|35|75|\x1b");
            	break;

	} // fim do switch

	if ( Opcao > 0 && Opcao < 36 )
	{
	   // le o status e o retorno de informacoes dos arquivos status.txt e
	   // retorno.txt criados pelo bemafilx.out
	   LeRetornoImpressora(1);
	}
    }
    while( Opcao != 0 );
}

void RetornoVariaveis2MFD( void )
{
    int  Opcao = 0;
    int  Retorno[4];
    int  RetFunction = 0;
    char Var[3000];
    char Aux;

    do
    {
    memset(Var,  '\x0',3000);
    Retorno[0] = 0; Retorno[1] = 0; Retorno[2] = 0; Retorno[3] = 0;

    system("clear");

    printf("                       Retorno de Informacoes MFD - Comando 35\n");

    printf("\n [ 1 ] - Flags Fiscais III                                                     ");
    printf("\n [ 2 ] - Venda Bruta                                                           ");
    printf("\n [ 3 ] - Troco                                                                 ");
    printf("\n [ 4 ] - Valor Recebido                                                        ");
    printf("\n [ 5 ] - Total ICMS no Cupom                                                   ");
    printf("\n [ 6 ] - Total ISSQN no Cupom                                                  ");

    printf("\n\n [ 0 ] - Sair" );

    printf("\n\n Digite a Opcao: " );

    scanf( "%d", &Opcao);
    switch( Opcao )
    {
        case 1: // Flags fiscais III - ESC 35 76
        GeraArquivoComando("\x1b|35|76|\x1b");
                break;

        case 2: // Venda bruta - ESC 35 77
        GeraArquivoComando("\x1b|35|77|\x1b");
                break;

        case 3: // Troco - ESC 35 78
        GeraArquivoComando("\x1b|35|78|\x1b");
                break;

        case 4: // Valor recebido - ESC 35 79
        GeraArquivoComando("\x1b|35|79|\x1b");
                break;

        case 5: // Total ICMS no cupom - ESC 35 80
        GeraArquivoComando("\x1b|35|80|\x1b");
                break;

        case 6: // Total ISSQN no cupom - ESC 35 81
        GeraArquivoComando("\x1b|35|81|\x1b");
                break;


    } // fim do switch

    if ( Opcao > 0 && Opcao < 7 )
    {
       // le o status e o retorno de informacoes dos arquivos status.txt e
       // retorno.txt criados pelo bemafilx.out
       LeRetornoImpressora(1);
    }

    }while( Opcao != 0 );
}


void GeraArquivoComando( Comando )
char* Comando;
{
    FILE*   Handle;

    /* //DEBUG
    int i = 0;
    for (i = 0; i < strlen(Comando); i++)
    {
    	printf("\nComando[%d]: [%c], [%x]", i, Comando[i], Comando[i] );
    }
    getchar();
    */

    // abre o arquivo bemafilx.cmd
    if ((Handle = fopen("bemafilx.cmd", "wb")) == NULL)
    {
       printf("Erro ao criar o arquivo bemafilx.cmd.\n");
       return;
    }

    // grava o comando no arquivo
    fprintf( Handle, "%s", Comando );

    // fecha o arquivo status.txt
    fclose( Handle );


    // executa o programa bemafilx para enviar o comando para a impressora
    system( "./bemafilx" );
    return;
}

/*------------------------------------------------------------------------------
    Funcao.....: LeRetornoImpressora (Parametros)

    Parametros.: Flag - Flag de configuracao:
    					0 - nao tem informacao alem do status para ser exibida
    					1 - tem informacao para ser exibida alem do status
    					2 - tem informacao mas nao exibe
    					3 - exibe o status mesmo se for 6,0,0,0

    Retorno....: Nao ha

    Objetivo...: Ler o status e as informações da impressora nos arquivos
    			 status.txt e retorno.txt e exibilas na tela.

    Programador: Rodrigo Raimundo Olimpio
------------------------------------------------------------------------------*/
void LeRetornoImpressora( Flag )
int Flag;
{
    char Aux;                       /* variavel auxiliar                    */
    char Caracter;                  /* caracter lido do arquivo .txt        */
    char RetornoImpressora[3000];   /* inform. da imp. Ex: numero cupom etc */
    FILE*   Handle;                 /* handle do arquivo                    */

    memset( RetornoImpressora, '\0', 3000 );

    // abre o arquivo status.txt
    if ((Handle = fopen("status.txt", "r")) == NULL)
    {
       printf("Erro ao abrir o arquivo status.txt.");
       printf( "\nPressione Enter para Continuar");
       Aux = getchar();
       Aux = getchar();
       return;
    }

    // le o status (ACK, ST1 e ST2) do arquivo status.txt
    while( ( Caracter = fgetc( Handle ) ) != EOF )
    {
	//printf( "Caracter: %c\n", Caracter );
	sprintf( RetornoImpressora + strlen( RetornoImpressora ),
	         "%c", Caracter );
    };

    // fecha o arquivo status.txt
    fclose( Handle );

	// exibe o status do comando apenas se for diferente de 6,0,0,0
	if( strcmp(RetornoImpressora, "6,0,0,0") != 0 || Flag == 3 )
    	printf( "\n Status da Impressora: %s", RetornoImpressora );

    // somente le o arquivo retorno.txt e exibe suas informacoes na tela se
    // for algum dos comandos de leitura de informacoes.
    switch( Flag )
    {
    	case 0: // nao tem retorno de informacoes
    		break;

    	case 1: // tem retorno de informacoes
    	{

       		//printf("\nVou ler o arquivo retorno.txt");

       		memset( RetornoImpressora, '\0', 3000 );

       		// abre o arquivo retorno.txt
       		if ((Handle = fopen("retorno.txt", "r")) != NULL)
       		{
          		// le o retorno de informacoes da impressora
          		while( ( Caracter = fgetc( Handle ) ) != EOF )
          		{
              		sprintf( RetornoImpressora + strlen( RetornoImpressora ),
	               		"%c", Caracter );
          		}//while( Caracter != EOF );

          		// fecha o arquivo status.txt
          		fclose( Handle );
        	}

       		printf( "\n Informacoes da Imp. : %s\n", RetornoImpressora );
    		break;
    	}

    	case 2: // tem retorno de informacoes mas nao exibe os dados
        	printf( "\n Informacoes da Imp. geradas no arquivo retorno.txt\n");
    		break;
    }

    printf( "\n Pressione Enter para Continuar");
    Aux = getchar();
    Aux = getchar();

    return;
}
void CodigoBarras( void )
{
    int  Opcao = 0;
    int  Retorno[4];
    int  RetFunction = 0;
    char Var[3000];
    char Aux;
    char strComando[200];           /* Comando enviado para a impressora    */

    do
    {
	memset(Var,  '\x0',3000);
	Retorno[0] = 0; Retorno[1] = 0; Retorno[2] = 0; Retorno[3] = 0;

	system("clear");

	printf("            Impressao de Codigo de Barras (Vinculado/Gerencial)\n");

	printf("\n [  1 ] - Configura Codigo de Barras" );
	printf("\n [  2 ] - EAN-13                    " );
	printf("\n [  3 ] - EAN-8                     " );
	printf("\n [  4 ] - CODABAR                   " );
	printf("\n [  5 ] - CODE 39                   " );
	printf("\n [  6 ] - CODE 93                   " );
	printf("\n [  7 ] - CODE 128                  " );
	printf("\n [  8 ] - ISBN                      " );
	printf("\n [  9 ] - ITF                       " );
	printf("\n [ 10 ] - MSI                       " );
	printf("\n [ 11 ] - PLESSEY                   " );
	printf("\n [ 12 ] - PDF-417                   " );
	printf("\n [ 13 ] - UPC-A                     " );
	printf("\n [ 14 ] - UPC-E                     " );
	printf("\n [ 0 ] - Sair" );

	printf("\n\n Digite a Opcao: " );

	scanf( "%d", &Opcao);
	switch( Opcao )
	{
		case 1: // configura codigo de barras
			// configura a altura dos codigos de barra
			sprintf( strComando, "\x1b|67|%s|\x1b", ALTURA_DEFAULT);
			GeraArquivoComando(strComando);

			// configura a largura das barras
			sprintf( strComando, "\x1b|67|%s|\x1b", BARRAS_MEDIAS);
			GeraArquivoComando(strComando);

			// configura a fonte para imprimir os caracteres do codigo (HRI)
			sprintf( strComando, "\x1b|67|%s|\x1b", FONTE_NORMAL);
			GeraArquivoComando(strComando);

			// configura a posicao dos caracteres do codigo (HRI)
			sprintf( strComando, "\x1b|67|%s|\x1b", CARACTERES_ABAIXO);
			GeraArquivoComando(strComando);

			// configura a margem esquerda do codigo
			sprintf( strComando, "\x1b|67|%s|\x1b", MARGEM_DEFAULT);
			GeraArquivoComando(strComando);

            break;

	    case 2: // imprime codigo de barras EAN-13
			sprintf( strComando, "\x1b|67|%s%s|\x1b", CMD_COD_EAN13, EAN13);
			GeraArquivoComando(strComando);
            break;

	    case 3: // imprime codigo de barras EAN-8
			sprintf( strComando, "\x1b|67|%s%s|\x1b", CMD_COD_EAN8, EAN8);
			GeraArquivoComando(strComando);
            break;

	    case 4: // imprime codigo de barras CODABAR
			sprintf( strComando, "\x1b|67|%s%s|\x1b", CMD_COD_CODABAR, CODABAR);
			GeraArquivoComando(strComando);
            break;

	    case 5: // imprime codigo de barras CODE 39
			sprintf( strComando, "\x1b|67|%s%s|\x1b", CMD_COD_CODE39, CODE39);
			GeraArquivoComando(strComando);
            break;

	    case 6: // imprime codigo de barras CODE 93
			sprintf( strComando, "\x1b|67|%s%c%s|\x1b", CMD_COD_CODE93, strlen(CODE93), CODE93);
			GeraArquivoComando(strComando);
            break;

	    case 7: // imprime codigo de barras CODE 128
			sprintf( strComando, "\x1b|67|%s%c%s|\x1b", CMD_COD_CODE128, strlen(CODE128), CODE128);
			GeraArquivoComando(strComando);
            break;

	    case 8: // imprime codigo de barras ISBN
			sprintf( strComando, "\x1b|67|%s%s|\x1b", CMD_COD_ISBN, ISBN);
			GeraArquivoComando(strComando);
            break;

	    case 9: // imprime codigo de barras ITF
			sprintf( strComando, "\x1b|67|%s%s|\x1b", CMD_COD_ITF, ITF );
			GeraArquivoComando(strComando);
            break;

	    case 10: // imprime codigo de barras MSI
			sprintf( strComando, "\x1b|67|%s%s|\x1b", CMD_COD_MSI, MSI );
			GeraArquivoComando(strComando);
            break;

	    case 11: // imprime codigo de barras PLESSEY
			sprintf( strComando, "\x1b|67|%s%s|\x1b", CMD_COD_PLESSEY, PLESSEY );
			GeraArquivoComando(strComando);
            break;

	    case 12: // imprime codigo de barras PDF-417
			sprintf( strComando, "\x1b|67|%s5430%s|\x1b", CMD_COD_PDF417, PDF417 );
			GeraArquivoComando(strComando);
            break;

	    case 13: // imprime codigo de barras UPC-A
			sprintf( strComando, "\x1b|67|%s%s|\x1b", CMD_COD_UPCA, UPCA );
			GeraArquivoComando(strComando);
            break;

	    case 14: // imprime codigo de barras UPC-E
			sprintf( strComando, "\x1b|67|%s%s|\x1b", CMD_COD_UPCE, UPCE );
			GeraArquivoComando(strComando);
            break;

	} // fim do switch

	if ( Opcao > 0 && Opcao < 15)
	{
	   // le o status e o retorno de informacoes dos arquivos status.txt e
	   // retorno.txt criados pelo bemafilx.out
	   LeRetornoImpressora(0);
	}
    }
    while( Opcao != 0 );
}

void EstornoCDCPosterior (void)
{
    EmitirCupomFiscal();
    EmitirCDC();
    EmitirCupomFiscal();

    // le o numero do cupom para passar no comando de estorno do CDC
    char Cupom[7];
    LerNumeroCupom(Cupom);
    //strcpy(Cupom, "000005"); //DEBUG

    long COOCupom = 0;
    long COOCDC = 0;

    COOCupom = atol(Cupom) - 2;
    COOCDC = atol(Cupom) - 1;

    // estorno CDC posterior
    char strComando[256];
    sprintf( strComando, "\x1b|75|Cartao          |00000000010000|%06ld|%06ld|12345678901234567890123456789|Fulano de tal.5...20...25..29|Rua da Paz, 500   20...25...30...35...40...45...50...55...60...65...70...75...80|\x1b", COOCupom, COOCDC);

    GeraArquivoComando(strComando);

}

void EmitirCupomFiscal(void)
{
    // abre o cupom fiscal
    GeraArquivoComando("\x1b|00|\x1b");
    // vende item
    GeraArquivoComando("\x1b|09|1            |Teste De Produto.............|II|0001|00000100|0000|\x1b");
    // inicia o fechamento do cupom - ESC 32
    GeraArquivoComando("\x1b|32|D|0000|\x1b");
     // programa e verifica forma de pagamento - ESC 71
    GeraArquivoComando("\x1b|71|Cartao          |\x1b");
    char IndiceFormaPagto[3];
    LerRetorno(IndiceFormaPagto);

    // efetua forma de pagamento - ESC 72
    char Comando[25];
    sprintf(Comando, "\x1b|72|%02d|00000000010000|\x1b", atoi(IndiceFormaPagto));
    GeraArquivoComando(Comando);
     // termina o fechamento do cupom fiscal - ESC 34
    GeraArquivoComando("\x1b|34|\x1b");
}

void EmitirCDC(void)
{
    // Abre comprovante de credito e debito - ESC 66
    GeraArquivoComando("\x1b|66|Cartao          |\x1b");

    // Imprime comprovante de credito e debito - ESC 67
    GeraArquivoComando("\x1b|67|Texto do comprovante de credito e debito|\x1b");

    // Fecha comprovante de credito e debito - ESC 21
    GeraArquivoComando("\x1b|21|\x1b");
}

int LerNumeroCupom( char * Cupom )
{
    GeraArquivoComando("\x1b|30|\x1b");
    return LerRetorno(Cupom);
}

int LerRetorno( char * buffer )
{
    char Caracter;                  /* caracter lido do arquivo .txt        */
    char RetornoImpressora[3000];   /* inform. da imp. Ex: numero cupom etc */
    FILE*   Handle;                 /* handle do arquivo                    */

    memset( RetornoImpressora, '0', sizeof(RetornoImpressora));

    // abre o arquivo retorno.txt
    if ((Handle = fopen("retorno.txt", "r")) != NULL)
    {
        int i = 0;
        // le o retorno de informacoes da impressora
        while( ( Caracter = fgetc( Handle ) ) != EOF )
        {
            //sprintf( RetornoImpressora + strlen( RetornoImpressora ),
            //    "%c", Caracter );
            buffer[i++] = Caracter;
        }//while( Caracter != EOF );
        buffer[i] = 0;

        // fecha o arquivo status.txt
        fclose( Handle );
    }
    else
        return 0;

    return 1;
}

void TelaAtivaDesativa (char * comando)
{
    char Opcao;
    do
    {
        printf(" Ativa ou Desativa <A/D>: " );
        getchar(); //para retirar o ENTER do buffer
        scanf("%c", &Opcao);
        //getchar(); //para retirar o ENTER do buffer
    }while (strchr("ADad", Opcao) == NULL);

    char temp[strlen(comando) + 7];
    if (Opcao == 'A' || Opcao == 'a')
    {
        sprintf(temp, "\x1b|%s|0|\x1b", comando);
    }
    else
    {
        sprintf(temp, "\x1b|%s|1|\x1b", comando);
    }
    GeraArquivoComando(temp);
    return;
}
